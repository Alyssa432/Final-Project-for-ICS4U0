import javax.swing.*;
import java.awt.event.*;

public class Level2Runner {
   private static int x = 0; // Counter for timing transitions
   private static Timer timer;
   private static boolean reachedEnding2 = false;

   public static void startGame(JFrame frame) {
      frame.getContentPane().removeAll();
      frame.revalidate();
      frame.repaint();
   
      Scene1T scene1 = new Scene1T();
      Scene2T scene2 = new Scene2T();
      Scene3T scene3 = new Scene3T();
      Scene4T scene4 = new Scene4T();
      Scene5C1 scene5C1 = new Scene5C1();
      Scene5C2 scene5C2 = new Scene5C2();
      Scene6C1 scene6C1 = new Scene6C1();
      Scene6C2 scene6C2 = new Scene6C2();
      Scene7C1 scene7C1 = new Scene7C1(); 
      Scene7C2 scene7C2 = new Scene7C2();
      
      frame.getContentPane().add(scene1);
      frame.revalidate();
      frame.repaint();
   
      timer = new Timer(150, 
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               x++;
            
               if (x == 34) {
                  frame.remove(scene1);
                  frame.add(scene2);
                  scene2.start();
                  frame.revalidate();
                  frame.repaint();
               } else if (x == 101) {
                  if (scene2.wasPassed()) {
                     frame.remove(scene2);
                     frame.add(scene3);
                     frame.revalidate();
                     frame.repaint();
                  } else {
                  // Reset to Scene 1 if escape or leave in Scene 2
                     x = 34; // Reset counter to start from Scene 1 again
                     startGame(frame);
                     timer.stop();
                  }
               } /*else if (x == 168) {
                  frame.dispose(); // End the game or next steps
                  timer.stop();
               }
               */ 
               // Transition from Scene 3 to Scene 4
               else if (x == 230) { // Adjust this based on your game flow
                  frame.remove(scene3);
                  frame.add(scene4);
                  frame.revalidate();
                  frame.repaint();
               }
               // Handle transition from Scene 4 based on choices
               else if (x == 290) { // Adjust this based on your game flow
                  if (scene4.isJumped()) { // Implement 'isJumped()' in Scene4 class
                     frame.remove(scene4);
                     frame.add(scene5C1);
                     frame.revalidate();
                     frame.repaint();
                  } else if (scene4.changedWays()) {
                     frame.remove(scene4);
                     frame.add(scene5C2);
                     frame.revalidate();
                     frame.repaint();
                  }
               }
               // Transition after Scene 5C1
               else if (x == 350) { 
                  frame.remove(scene5C1);
                  frame.add(scene6C1);
                  frame.revalidate();
                  frame.repaint();
               }
               // After Scene 5C2
               else if (x == 410) { 
                  frame.remove(scene5C2);
                  frame.add(scene6C2);
                  frame.revalidate();
                  frame.repaint();
               }
               // Logic to transition based on choices from Scene 6
               else if(x == 470) {
                  if(true) {
                     frame.remove(scene6C1);
                     frame.add(scene7C1);
                     reachedEnding2 = false;
                     frame.revalidate();
                     frame.repaint();
                  }
                  else {
                     frame.remove(scene6C2);
                     frame.add(scene7C2);
                     reachedEnding2 = true;
                     frame.revalidate();
                     frame.repaint();
                  }
               }
               
               else if ((x == 530) && (reachedEnding2)) {
                  frame.remove(scene7C2);
                  x = 0;
                  timer.stop();
                  startGame(frame);
               }   
               
            }
            
         });
   
      timer.start();
   }
}
