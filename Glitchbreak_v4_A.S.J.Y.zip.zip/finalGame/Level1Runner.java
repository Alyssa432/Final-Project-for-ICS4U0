import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Level1Runner {
    private static int x = 0;
    private static Timer timer;

    public static void starts(JFrame frame) { 
        frame.getContentPane().removeAll(); 
        frame.revalidate();
        frame.repaint();

        Scene1 scene1 = new Scene1(frame);
        Scene2 scene2 = new Scene2(frame);
        Scene3 scene3 = new Scene3(frame);
        Scene4 scene4 = new Scene4(frame);
        Scene5 scene5 = new Scene5(frame);
        Scene6 scene6 = new Scene6(frame);

        frame.getContentPane().add(scene1);                       
        frame.revalidate();
        frame.repaint();

        timer = new Timer(150, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                x++;

                if (x == 66) {
                    frame.getContentPane().remove(scene1);

                    frame.add(scene2);
                    frame.revalidate();
                    frame.repaint();
                } else if (x == 100) {
                    frame.remove(scene2);
                    frame.add(scene3);
                    frame.revalidate();
                    frame.repaint();
                } else if (x == 134) {
                    frame.remove(scene3);
                    frame.add(scene4);
                    scene4.start();
                    frame.revalidate();
                    frame.repaint();
                } else if (x == 200) {
                    frame.remove(scene4);
                    frame.add(scene5);
                    scene5.start();
                    frame.revalidate();
                    frame.repaint();
                } else if (x == 240) {
                    frame.remove(scene5);
                    frame.add(scene6);
                    scene6.start();
                    frame.revalidate();
                    frame.repaint();
                    timer.stop();
                }
            }
        });

        timer.start(); 
    }
}
