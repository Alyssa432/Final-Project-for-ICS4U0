// Alyssa Samji and Jessica Yang
// Scene 5 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene5 extends JPanel {
   private int x = 0;
   private BufferedImage friendStandRight, standLeft, textBox, spa;
   private Timer timer;

   public Scene5(JFrame frame) {
      try {
         friendStandRight = ImageIO.read(new File("friendStandRight.png"));
         standLeft = ImageIO.read(new File("standLeft.png"));
         textBox = ImageIO.read(new File("TextBoxReverse.png"));
         spa = ImageIO.read(new File("spa.png"));
      } catch (IOException e) {
      }
      timer = new Timer(150, 
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               x += 1;
               repaint();
            }
         });
   }

    
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      
      g.setFont(serifFont);
      
      Color sky = new Color(206, 237, 250);
      Color grass = new Color(170, 239, 80);
   
      g.setColor(sky);
      g.fillRect(0, 0, 800, 600);
      
      g.setColor(grass);
      g.fillRect(0, 300, 800,300);
      
      g.setColor(Color.GRAY);
      int[] yPoints = {300, 300, 600, 600};
      int[] xPoints = {300, 500, 800, 0};
      g.fillPolygon(xPoints, yPoints, 4);
         
      g.drawImage(friendStandRight, 100, 250, 200, 400, null);   
      g.drawImage(textBox, 250, 150, 160, 150, null);
      g.setColor(Color.BLACK);
      g.drawString("Let's go", 310, 215);
      g.drawString("to the spa!", 300, 235);
      g.drawImage(standLeft, 505, 245, 200, 400, null);
      
      if (x > 10){
         g.drawImage(spa, 200, 50, 400, 300, null);
         g.setColor(sky);
         g.fillRect(0, 0, 800, 600);
      
         g.setColor(grass);
         g.fillRect(0, 300, 800,300);
      
         g.setColor(Color.GRAY);
         int[] yPoints2 = {300, 300, 600, 600};
         int[] xPoints2 = {300, 500, 800, 0};
         g.fillPolygon(xPoints2, yPoints2, 4);
         
         g.drawImage(friendStandRight, 100, 250, 200, 400, null);   
         g.drawImage(textBox, 250, 150, 160, 150, null);
         g.setColor(Color.BLACK);
         g.drawString("Let's go", 310, 215);
         g.drawString("to the spa!", 300, 235);
         g.drawImage(standLeft, 505, 245, 200, 400, null);
      }
   }
        
   public void start() {
      timer.start();
   }

}