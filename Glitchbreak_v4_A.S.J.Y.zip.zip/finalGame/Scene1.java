// Alyssa Samji and Jessica Yang
// Scene 1 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene1 extends JPanel {
    private int x = 0;
    private int imageState = 1; 
    private BufferedImage walkRFoot, standLeft, walkLFoot, friendStandLeft, friendWalkRFoot, friendWalkLFoot, textBox;
    private Timer timer;

    public Scene1(JFrame frame) {
    
    this.setPreferredSize(new Dimension(800, 600));
        try {
            walkRFoot = ImageIO.read(new File("walkRFoot.png"));
            standLeft = ImageIO.read(new File("standLeft.png"));
            walkLFoot = ImageIO.read(new File("walkLFoot.png"));
            friendStandLeft = ImageIO.read(new File("friendStandLeft.png"));
            friendWalkRFoot = ImageIO.read(new File("friendWalkRFoot.png"));
            friendWalkLFoot = ImageIO.read(new File("friendWalkLFoot.png"));
            textBox = ImageIO.read(new File("TextBox.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        timer = new Timer(150, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                x += 20;

                imageState++;
                if (imageState > 3) imageState = 1;

                repaint();
            }
        });
        timer.start();
    }

    public void paintComponent(Graphics g) {
    super.paintComponent(g);
        Color road = new Color(198, 198, 198);
        Color sky = new Color(206, 237, 250);
        Color grass = new Color(170, 239, 80);

        g.setColor(sky);
        g.fillRect(0, 0, getWidth(), 400);

        g.setColor(grass);
        for (int i = 0; i < getWidth(); i += 10) {
            int random = (int) (Math.random() * 7) + 3;
            int[] xPoints = {i, i + random, i + 2 * random};
            int[] yPoints = {400, 300 - 2 * random, 400};
            g.fillPolygon(xPoints, yPoints, 3);
        }

        g.setColor(road);
        g.fillRect(0, 400, getWidth(), getHeight() - 400);

        g.setColor(Color.YELLOW);
        g.fillOval(650, 10, 100, 100);

        BufferedImage currentImage, currentImage2;

        if (imageState == 1) {
            currentImage = walkLFoot;
            currentImage2 = friendStandLeft;
        } else if (imageState == 2) {
            currentImage = standLeft;
            currentImage2 = friendWalkRFoot;
        } else {
            currentImage = walkRFoot;
            currentImage2 = friendWalkLFoot;
        }

        g.drawImage(currentImage2, 920 - x, 200, 150, 240, null);
        g.drawImage(currentImage, 845 - x, 200, 150, 240, null);

        Font serifFont = new Font("Serif", Font.BOLD, 15);
        g.setFont(serifFont);
        g.setColor(Color.BLACK);

        if (x > 200) {
            g.drawImage(textBox, 645 - x, 150, 200, 100, null);
            g.drawString("I mean it!", 715 - x, 180);
            g.drawString("We need to ", 685 - x, 200);
            g.setColor(Color.RED);
            g.drawString("escape", 765 - x, 200);
            g.setColor(Color.BLACK);
            g.drawString("!", 815 - x, 200);
        }

        if (x > 350) {
            g.drawLine(765 - x, 193, 805 - x, 202);
            g.setColor(Color.GREEN);
            g.drawString("relax", 765 - x, 215);
        }
    }
    }

/** 
The GUI Tutorials did not explicitly teach me how to move pictures. I used information
that I learned from those tutorials, like about JPanel along with my knowledge from
Grade 11 to accomplish movement. For the JPanels, I had to research a way to iterate/
time the movement. That is why I used the resource below as it taught me about Swing
Timer. 
https://stackoverflow.com/questions/32753169/how-to-use-a-swing-timer-with-jpanel
*/
