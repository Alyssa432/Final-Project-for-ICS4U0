import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene5C1 extends JPanel{
   private BufferedImage ch1, wall;
   private boolean showDialogue;
   
   public Scene5C1 () {
      showDialogue = false;
      setBackground(new Color(200, 200, 200));
      try {
         ch1 = ImageIO.read (new File ("standBack.png"));
         wall = ImageIO.read (new File ("wearAndTearLol.png"));
      }catch (IOException e) {}  
      
      // Show dialogue after 2s
      Timer dialogTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               showDialogue = true;
               repaint();
            }
         });
      dialogTimer.start();    
   }
   
   @Override
   public void paintComponent (Graphics g) {
      super.paintComponent(g);
      
      g.drawImage(wall, 0, 0, 800, 600, null);
      
      g.setColor(new Color(100, 100, 100));
      g.fillRect(0, 450, getWidth(), 150);
      
      g.drawImage(ch1, 330, 300, 160, 300, null);
      
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 16));      
         g.drawString("Beyond the fence, there is only concrete.", 70, 475);
         g.drawString("The grass has disappeared. The sky has disappeared.", 70, 500);
         g.drawString("You are now in an old, dilapidated room.", 70, 525);
         //g.setFont (new Font ("Courier New", Font.PLAIN, 11));
         //g.drawString("click anywhere to continue!", 200, 540);
      }
   }
   
   public static void main (String[] args) {
      JFrame frame = new JFrame("Scene5 choice 1 Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(new Scene5C1());
      frame.setSize(800, 600);
      frame.setVisible(true);
   }
}