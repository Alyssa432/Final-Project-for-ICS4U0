import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;


public class Scene4T extends JPanel {
   private BufferedImage background, ch1, fence, satchel;
   private boolean jumpChosen = false;
   private boolean changeWaysChosen = false;
   private boolean showDialogue;
   private JButton jumpButton, changeWaysButton;
   
   public Scene4T() {
      setBackground(new Color(176, 231, 255));
      setLayout(null);
      showDialogue = false;
   
      try {
         background = ImageIO.read(new File("background2.png"));
         ch1 = ImageIO.read(new File("standBack.png"));
         fence = ImageIO.read (new File ("fence.png"));
         satchel = ImageIO.read (new File ("satchel.png"));
      }catch (IOException e) {}
      
      jumpButton = new JButton("Jump");
      changeWaysButton = new JButton("Change Ways");
   
      jumpButton.setBounds(200, 350, 100, 30); 
      changeWaysButton.setBounds(500, 350, 140, 30);
   
      jumpButton.setVisible(false);
      changeWaysButton.setVisible(false);
   
      add(jumpButton);
      add(changeWaysButton);
   
      jumpButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               jumpChosen = true;
            }
         });
     
      changeWaysButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               changeWaysChosen = true;
            }
         });
      
      Timer dialogTimer = new Timer(1000, 
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               showDialogue = true;
               jumpButton.setVisible(true);
               changeWaysButton.setVisible(true);
               repaint();
            }
         });
      dialogTimer.start();
      
      
   }
   
   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
      
      g.drawImage(fence, 0, 0, 800, 600, null); 
      g.drawImage(background, 0, 0, 800, 600, null);
      g.drawImage(satchel, 300, 348, 160, 200, null);
      g.drawImage(ch1, 330, 200, 158, 300, null);
      
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 16));      
         g.drawString("A fence appears in your path. Will you jump the fence or", 70, 475);
         g.drawString("change ways? As you think, you hear a robotic whirr", 70, 500);
         g.drawString("getting closer...something is chasing you!", 70, 525);
      }
   }
   
   public boolean isJumped () {
      return jumpChosen;
   }
   
   public boolean changedWays () {
      return changeWaysChosen;
   }
   
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene4T Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(new Scene4T());
      frame.setSize(800, 600);
      frame.setVisible(true);
   }
 
}