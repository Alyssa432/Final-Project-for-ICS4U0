import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene7C2 extends JPanel {
   private int x, transparency;
   private BufferedImage standLeft, background, robot;
   private Timer dialogTimer, rainTimer, failTimer;
   private boolean showDialogue, showFailScreen;
   private int[] rainX, rainY, rainSpeed;

   public Scene7C2() {
      setBackground(new Color(176, 231, 255));
      showDialogue = false;
      showFailScreen = false;
   
      try {
         background = ImageIO.read(new File("background3.png"));
         standLeft = ImageIO.read(new File("standLeft.png"));
         robot = ImageIO.read (new File ("robot.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
      
      int numDrops = 100;
      rainX = new int[numDrops];
      rainY = new int[numDrops];
      rainSpeed = new int[numDrops];
   
      for (int i = 0; i < numDrops; i++) {
         rainX[i] = (int)(Math.random() * 800);
         rainY[i] = (int)(Math.random() * 600);
         rainSpeed[i] = 2 + (int)(Math.random() * 4);
      }
      
      dialogTimer = new Timer(800, 
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               showDialogue = true;
               repaint();
            }
         });
      dialogTimer.setRepeats(false);
      dialogTimer.start();
   
      // Rain animation timer
      rainTimer = new Timer(20, 
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               for (int i = 0; i < rainY.length; i++) {
                  rainY[i] += rainSpeed[i];
                  if (rainY[i] > 600) {
                     rainY[i] = 0;
                     rainX[i] = (int)(Math.random() * 800);
                  }
               }
               repaint();
            }
         });
      rainTimer.start();
      
      failTimer = new Timer (1000, 
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               showFailScreen = true;
               repaint();
            }
         });
      rainTimer.start();
   
      
   }
   
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      
      //grey skies :smirk:
      g.setColor(new Color(128, 128, 128, 160));
      g.fillRect(0, 0, getWidth(), getHeight());
      
      g.drawImage(background, 0, 0, 800, 600, null);
      
      g.drawImage(standLeft, 600, 200, 130, 210, null);
      g.drawImage(robot, 100, 200, 180, 210, null);
   
      // Draw rain
      g.setColor(new Color(255, 255, 255, 150)); //last value is transparency
      for (int i = 0; i < rainX.length; i++) {
         g.drawLine(rainX[i], rainY[i], rainX[i], rainY[i] + 10);
      }
   
      // Dialogue box
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 14));      
         g.drawString("Suddenly, you're stopped by a robotic whir. 'You shall not pass, human!'", 70, 470);
         g.drawString("They've caught onto you! Before you can even think about it, there's a flash,", 70, 495);
         g.drawString("and you are sent back home.", 70, 520);
      }
      
      if (showFailScreen) {
         g.setColor(Color.BLACK);
         g.fillRect(0, 0, getWidth(), getHeight());
         g.setColor(Color.RED);
         g.setFont(new Font("Courier New", Font.BOLD, 36));
         g.drawString("The AI caught you! Fail!", 120, 300);
      }
      
   }
   
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene7C2 Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(new Scene7C2());
      frame.setSize(800, 600);
      frame.setVisible(true);
   }
}