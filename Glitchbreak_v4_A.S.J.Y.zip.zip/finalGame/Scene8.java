import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class Scene8 extends JPanel implements ActionListener, KeyListener {
   private Timer timer;
   private int playerY = 250;
   private int playerHeight = 60;
   private int groundY = 250;
   private String state = "stand"; // stand, jump, duck
   private int jumpVelocity = 0;

   private ArrayList<Rectangle> obstacles = new ArrayList<>();
   private int spawnCounter = 0;
   private Random rand = new Random();

   private boolean gameOver = false;

   public Scene8() {
      setFocusable(true);
      addKeyListener(this);
      setBackground(Color.WHITE);
      timer = new Timer(20, this);
      timer.start();
   }

   @Override
   public void actionPerformed(ActionEvent e) {
      if (gameOver) {
         timer.stop();
         return;
      }

      //jump
      if (state.equals("jump")) {
         playerY += jumpVelocity;
         jumpVelocity += 1; // gravity
         if (playerY >= groundY) {
            playerY = groundY;
            state = "stand";
            jumpVelocity = 0;
         }
      }

      //duck
      if (state.equals("duck")) {
         playerHeight = 30;
      } else {
         playerHeight = 60;
      }

      // Moving obstacles
      for (int i = 0; i < obstacles.size(); i++) {
         Rectangle obs = obstacles.get(i);
         obs.x -= 5;
         if (obs.x + obs.width < 0) {
            obstacles.remove(i);
            i--; // Avoid skipping the next obstacle
         }
      }

      // Spawn obstacles randomly
      spawnCounter++;
      if (spawnCounter > 70) {
         spawnCounter = 0;
         boolean high = rand.nextBoolean();
         if (high) {
            obstacles.add(new Rectangle(600, groundY - 60, 30, 30)); // high
         } else {
            obstacles.add(new Rectangle(600, groundY, 30, 30)); // low
         }
      }

      // Collision detection
      Rectangle playerRect = new Rectangle(100, playerY + (50 - playerHeight), 30, playerHeight);
      for (Rectangle obs : obstacles) {
         if (playerRect.intersects(obs)) {
            // If player is jumping and hits a high obstacle or
            // player is standing and hits a low obstacle
            if ((state.equals("jump") && obs.y == groundY - 60) || 
                ((state.equals("stand") || state.equals("duck")) && obs.y == groundY)) {
               gameOver = true;
               repaint();
               return;
            }
         }
      }

      repaint();
   }

   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);

      if (gameOver) {
         g.setColor(Color.BLACK);
         g.fillRect(0, 0, getWidth(), getHeight());

         g.setColor(Color.RED);
         g.setFont(new Font("Courier New", Font.BOLD, 36));
         g.drawString("The AI caught you! Fail!", 120, 150);
         return;
      }

      // Ground
      g.setColor(Color.GRAY);
      g.fillRect(0, groundY + 50, getWidth(), 5);

      // Character
      g.setColor(Color.BLUE);
      g.fillRect(100, playerY + (50 - playerHeight), 30, playerHeight);

      // Obstacles
      g.setColor(Color.RED);
      for (Rectangle obs : obstacles) {
         g.fillRect(obs.x, obs.y + (50 - obs.height), obs.width, obs.height);
      }
   }

   @Override
   public void keyPressed(KeyEvent e) {
      if (gameOver) return;

      if (e.getKeyCode() == KeyEvent.VK_UP && state.equals("stand")) {
         state = "jump";
         jumpVelocity = -20;  // increased jump velocity for longer jump
      } else if (e.getKeyCode() == KeyEvent.VK_DOWN && state.equals("stand")) {
         state = "duck";
      }
   }

   @Override
   public void keyReleased(KeyEvent e) {
      if (gameOver) return;

      if (e.getKeyCode() == KeyEvent.VK_DOWN && state.equals("duck")) {
         state = "stand";
      }
   }

   @Override
   public void keyTyped(KeyEvent e) {}

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene8 - T-Rex Style Game");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(800, 400);   // Adjust size as needed
      frame.setResizable(false);

      Scene8 scene8 = new Scene8();
      frame.add(scene8);

      frame.setLocationRelativeTo(null);  // Center the window
      frame.setVisible(true);
   }
}


//resources: Key Events: https://www.geeksforgeeks.org/java-keylistener-in-awt/
//                       https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyEvent.html
//           collision:  https://docs.oracle.com/javase/8/docs/api/java/awt/Rectangle.html