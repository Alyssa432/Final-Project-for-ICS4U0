import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Instructions {
    public static void starts(JFrame frame) { 
        frame.getContentPane().removeAll(); 
        frame.revalidate();
        frame.repaint();
}
}