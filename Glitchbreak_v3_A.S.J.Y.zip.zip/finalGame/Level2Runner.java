import javax.swing.*;
import java.awt.event.*;

public class Level2Runner {
    private static int x = 0;
    private static Timer timer;

    public static void startGame(JFrame frame) {
        frame.getContentPane().removeAll();
        frame.revalidate();
        frame.repaint();

        Scene1T scene1 = new Scene1T();
        Scene2T scene2 = new Scene2T();
        Scene3T scene3 = new Scene3T();

        frame.getContentPane().add(scene1);                      
        frame.revalidate();
        frame.repaint();

        timer = new Timer(150, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                x++;

                if (x == 34) {
                    frame.remove(scene1);
                    frame.add(scene2);
                    scene2.start();
                    frame.revalidate();
                    frame.repaint();
                } else if (x == 101) {
                    if (scene2.wasPassed()) {
                        frame.remove(scene2);
                        frame.add(scene3);
                        frame.revalidate();
                        frame.repaint();
                    } else {
                        frame.dispose();
                        timer.stop();
                    }
                } else if (x == 168) {
                    frame.dispose();
                    timer.stop();
                }
            }
        });

        timer.start();
    }
}

