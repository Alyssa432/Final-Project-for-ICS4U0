public class Scene7C2 extends JPanel {
   public Scene7C2() {
      
   }
}