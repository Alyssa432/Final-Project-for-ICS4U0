// Alyssa Samji and Jessica Yang
// Scene 3 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene3 extends JPanel {
   private int x = 0;
   private BufferedImage friendStandRight, faceForwardSassy, textBox;

   public Scene3(JFrame frame) {
      try {
         friendStandRight = ImageIO.read(new File("friendStandRight.png"));
         faceForwardSassy = ImageIO.read(new File("faceForwardSassy.png"));
         textBox = ImageIO.read(new File("TextBoxReverse.png"));
      } catch (IOException e) {
      }
   }

   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      g.setFont(serifFont);
      Color sky = new Color(206, 237, 250);
      g.setColor(sky);
      g.fillRect(0, 0, 800, 600);
      g.drawImage(friendStandRight, 100, 250, 200, 400, null);   
      g.drawImage(textBox, 250, 150, 300, 150, null);
      g.setColor(Color.BLACK);
      g.drawString("How strange!", 350, 200);
      g.drawString("I swear there was a road there. I", 300, 220);
      g.drawString("guess we'll go somewhere else!", 300, 240);
      g.drawImage(faceForwardSassy, 505, 245, 200, 400, null);   
   }
}