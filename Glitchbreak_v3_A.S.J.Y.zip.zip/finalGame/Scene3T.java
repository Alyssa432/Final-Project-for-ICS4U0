import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene3T extends JPanel {
   private BufferedImage background, ch2, ch1, ch3, satchel;
   private int y, imgState;
   private Timer walkTimer;

   public Scene3T() {
      setSize(800, 600);
      setBackground(new Color(176, 231, 255));
      y = 0;
   
      try {
         background = ImageIO.read(new File("background2.png"));
         ch2 = ImageIO.read(new File("standBack.png"));
         ch1 = ImageIO.read(new File("walkBackLeft.png"));
         ch3 = ImageIO.read(new File("walkBackRight.png"));
         satchel = ImageIO.read (new File ("satchel.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   
      walkTimer = new Timer(85, 
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               if (y < 200) {
                  y +=3; // Move up by 2 pixels per frame
                  imgState ++;
               
                  if (imgState > 2) imgState = 0;
                  repaint();
               }
            }
         });
      
   }

   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
   
      g.drawImage(background, 0, 0, 800, 600, null);
      g.drawImage(satchel, 300, 548-y, 160, 200, null);
      
      BufferedImage currentImg;
      
      if (imgState == 1)
         currentImg = ch1;
      else if (imgState == 2)
         currentImg = ch3;
      else
         currentImg = ch2;
      
      
      g.drawImage(currentImg, 330, 400 - y, 158, 300, null); // Walks "up"
   }
   
   public static void main(String[] args) {
      Scene3T n = new Scene3T();
      JFrame frame = new JFrame("Scene3T Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(n);
      frame.setSize(800, 600);
      frame.setVisible(true);
      n.starts();
   }
   
   public void starts () {
      walkTimer.start();
   }
}
