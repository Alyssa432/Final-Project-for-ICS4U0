/*Jessica Yang and Alyssa Samji
Game Menu -- Jessica Yang
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import java.io.File;

public class MainMenu extends JFrame{
   public MainMenu() { 
      //main frame
      setSize(800, 600);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      getContentPane().setBackground(new Color (242, 218, 241));
      setLayout(new GridBagLayout());
   
      //background img
      ImageIcon backgroundImg = new ImageIcon("glitchBreak.png");
      Image temp = backgroundImg.getImage();
      Image tempScaled = temp.getScaledInstance(800, 580,java.awt.Image.SCALE_SMOOTH);
      backgroundImg = new ImageIcon (tempScaled);
      JLabel backgroundLabel = new JLabel(backgroundImg);
      backgroundLabel.setLayout(new GridBagLayout());
         
      //button panel
      JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 0, 10));
      buttonPanel.setOpaque(false); // So background shows through
   
      //buttons
      JButton instructionsButton = new JButton("Instructions");
      JButton playButton = new JButton("Play");
      JButton exitButton = new JButton("Exit");
   
      //Add buttons to panel
      buttonPanel.add(instructionsButton);
      buttonPanel.add(playButton);
      buttonPanel.add(exitButton);
   
      //add panel to background label
      backgroundLabel.add(buttonPanel);
      setContentPane(backgroundLabel);
   
      //action listeners
      instructionsButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               JFrame instructionsFrame = new JFrame("Instructions");
               instructionsFrame.setSize(600, 400);
               instructionsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
               instructionsFrame.setVisible(true);
            }
         });
   
      playButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               JFrame playFrame = new JFrame("Play");
               playFrame.setSize(600, 400);
               playFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
               playFrame.setVisible(true);
            }
         });
   
      exitButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               System.exit(0);
            }
         });
   
      setLocationRelativeTo(null);
      setVisible(true);
   }

   public static void main(String[] args) {
      new MainMenu();
   }
}

/* resources: 
   how to rescale an imageIcon: https://stackoverflow.com/questions/6714045/how-to-resize-jlabel-imageicon
   ICS3UP past projects
   ICS4UO classroom materials and past projects 
*/
