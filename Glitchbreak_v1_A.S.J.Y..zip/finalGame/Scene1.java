Scene 1
// Alyssa Samji and Jessica Yang
// Scene 1 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene1 extends JPanel {
    private int x = 0;
    private boolean toggleImage = false;
    private BufferedImage sideWalking1, sideWalking2, sideWalking3, friendWalking1, friendWalking2, friendWalking3, textBox;

    public Scene1(JFrame frame) {
        try {
            sideWalking1 = ImageIO.read(new File("sideWalking1.png"));
            sideWalking2 = ImageIO.read(new File("sideWalking2.png"));
            sideWalking3 = ImageIO.read(new File("sideWalking3.png"));
            friendWalking1 = ImageIO.read(new File("friendWalking1.png"));
            friendWalking2 = ImageIO.read(new File("friendWalking2.png"));
            friendWalking3 = ImageIO.read(new File("friendWalking3.png"));
            textBox = ImageIO.read(new File("TextBox.png"));
        } catch (IOException e) {
        }

Timer timer = new Timer(100, new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        x += 10;

        toggleImage = !toggleImage;
        repaint();
    }
});
timer.start();

    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Color road = new Color(198, 198, 198);
        Color sky = new Color(206, 237, 250);
        Color grass = new Color(170, 239, 80);

        g.setColor(sky);
        g.fillRect(0, 0, getWidth(), 400);

        g.setColor(grass);
        for (int i = 0; i < getWidth(); i += 10) {
            int random = (int) (Math.random() * 7) + 3;
            int[] xPoints = {i, i + random, i + 2 * random};
            int[] yPoints = {400, 300 - 2 * random, 400};
            g.fillPolygon(xPoints, yPoints, 3);
        }

        g.setColor(road);
        g.fillRect(0, 400, getWidth(), getHeight() - 400);

        g.setColor(Color.YELLOW);
        g.fillOval(650, 10, 100, 100);

        BufferedImage currentImage, currentImage2;
      if (toggleImage) {
    currentImage = sideWalking1;
    currentImage2 = friendWalking1;
} else {
    currentImage = sideWalking2;
    currentImage2 = friendWalking2;
    }
    
        g.drawImage(currentImage2, 810 - x, 200, 150, 240, null);
        g.drawImage(currentImage, 845 - x, 200, 150, 240, null);
        
        Font serifFont = new Font("Serif", Font.BOLD, 15);
        g.setFont(serifFont);
        g.setColor(Color.BLACK);
            
        if (x > 200) {
            g.drawImage(textBox, 600 - x, 150, 200, 100, null);
            g.drawString("I mean it!", 670 - x, 180);
            g.drawString("We need to ", 640 - x, 200);
            g.setColor(Color.RED);
            g.drawString("escape", 720 - x, 200);
            g.setColor(Color.BLACK);
            g.drawString("!", 770  - x, 200);
            }
            
        if (x > 300) {
            g.drawLine(720 - x, 193, 760 - x, 202);
            g.setColor(Color.GREEN);
            g.drawString("relax", 720  - x, 215);
        }
    }
}

/** 
The GUI Tutorials did not explicitly teach me how to move pictures. I used information
that I learned from those tutorials, like about JPanel along with my knowledge from
Grade 11 to accomplish movement. For the JPanels, I had to research a way to iterate/
time teh movement. That is why I used the resource below as it taught me about Swing
Timer. 
https://stackoverflow.com/questions/32753169/how-to-use-a-swing-timer-with-jpanel
*/ 
