// Alyssa Samji and Jessica Yang
// Scene 2 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene2 extends JPanel {
    private int x = 0;
    private BufferedImage brickWall;

    public Scene2(JFrame frame) {
        try {
            brickWall = ImageIO.read(new File("brickWall.png"));
        } catch (IOException e) {
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(brickWall, 0, 0, 800, 600, null);        
        }
    }
