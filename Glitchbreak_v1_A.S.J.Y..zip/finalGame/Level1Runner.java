// Alyssa Samji and Jessica Yang
// Level 1 Main Runner
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import javax.swing.*;
import java.awt.*;
public class Level1Runner
{
public static void main (String[] args)
{
        JFrame frame = new JFrame("Scene1");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        Scene1 scene = new Scene1(frame);
        frame.add(scene);

        frame.setVisible(true);
}
}

