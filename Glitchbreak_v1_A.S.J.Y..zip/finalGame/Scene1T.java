import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene1T extends JPanel { 
   private BufferedImage scene1;
   
   public Scene1T() {
      JFrame main = new JFrame();
      main.setSize(800, 600);
      main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         
      //background img
      
      /*
      ImageIcon backgroundImg = new ImageIcon("scene1.png");
      Image temp = backgroundImg.getImage();
      Image tempScaled = temp.getScaledInstance(800, 580,java.awt.Image.SCALE_SMOOTH);
      backgroundImg = new ImageIcon (tempScaled);
      JLabel backgroundLabel = new JLabel(backgroundImg);
      backgroundLabel.setLayout(new GridBagLayout());
      
      setContentPane(backgroundLabel);
      
      setVisible(true);
      */
      
      try {
         scene1 = ImageIO.read (new File ("scene1.peng"));
      } catch (IOException e) {
      }
   
   }
   
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      g.drawImage(scene1, 0, 0, 800, 600, null);        
   }

   
   public static void main (String[] args) {
      new Scene1T();
   }
}