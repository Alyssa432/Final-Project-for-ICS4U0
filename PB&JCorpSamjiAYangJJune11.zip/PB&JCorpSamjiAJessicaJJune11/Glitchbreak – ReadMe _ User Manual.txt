﻿Glitchbreak – ReadMe / User Manual
Created by: Jessica Yang and Alyssa Samji
Course: ICS4U - Final ISP Project
Teacher: Ms. Krasteva
Date: June 2025


________________


About the Game
Glitchbreak is a narrative-based Java game that depicts how much power AI can have over peoples’ day to day lives, especially when they’re completely oblivious to it. The story follows the player through different scenes and choices that show their life, where AI has completely taken control over their world, influencing their decisions and giving no privacy, just like it does in real life through things like social media and smart devices. Glitchbreak as a game is designed to make the player think deeper and more critically about the role AI technology plays in their own lives.


How to Run The Program
To play the game, run the GameLauncher.java file.
This file controls the menu of the game, which connects the two levels.


Requirements:
* Java 8 or later
* Use JGRASP as the IDE

How to Run:
   * Open the project in your IDE.
   * Compile all .java files (Ctrl + B)
   * Right-click GameLauncher.java and click Run (or click the red running man symbol in the top bar).


Usage Example
   * When you launch the game, it begins with asking for the user name.
You’ll be prompted to type in responses or click buttons using your mouse. Your choices affect how the story plays out.
   * Example:
If you type a keyword like "obey" (which is not an actual keyword in the game) when prompted, it might lead to a more controlled or darker ending. On the other hand, if you avoid these keywords, you will be able to progress through the game.


Troubleshooting
      * Ensure all image files (like pod.png, faceForwardSassy.png, etc.) are in the correct folder. Otherwise, they will not show up on screen.