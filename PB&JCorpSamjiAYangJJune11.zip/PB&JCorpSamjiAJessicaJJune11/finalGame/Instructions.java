import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * The Instructions class displays the instructions screen for the Glitchbreak game.
 * It clears the existing JFrame content and adds a panel that explains the game's
 * narrative purpose, interaction tips, and scene-specific behaviors. A "Back to Menu"
 * button allows the user to return to the main menu.
 * 
 * Usage:
 * Call Instructions.starts(frame) to display the instructions screen.
 * 
 * Author: Jessica Yang and Alyssa Samji
 * Date: June 11, 2025
 * Project: Glitchbreak Final ISP
 */
public class Instructions {

    /**
     * Displays the instructions screen on the given JFrame.
     * 
     * @param frame The main JFrame where the instructions panel will be shown.
     */
    public static void starts(JFrame frame) {
        // Clear the frame
        frame.getContentPane().removeAll();
        frame.revalidate();
        frame.repaint();

        // Create a new panel with a soft teal background
        JPanel panel = new JPanel();
        panel.setBackground(new Color(223, 245, 243)); // soft teal
        panel.setLayout(new BorderLayout());

        // Text area containing the game instructions
        JTextArea instructions = new JTextArea(
            "Glitchbreak is a narrative-based Java game that depicts how much power AI can have over peoples’ day-to-day lives,\n" +
            "especially when they’re completely oblivious to it. The story follows the player through different scenes and choices\n" +
            "that show their life, where AI has completely taken control over their world, influencing their decisions and giving\n" +
            "no privacy, just like it does in real life through things like social media and smart devices.\n" +
            "Glitchbreak is designed to make the player think deeper and more critically about the role AI plays in their own lives.\n\n" +
            "- Follow along with the narrative.\n" +
            "- In Scene 2, be quick to click the dialogue box to input your message (keyboard), or the game will assume you've gone AFK and restart.\n" +
            "- In Scene 4, if no option is picked with your mouse, the game will automatically choose 'change ways' for you.\n" +
            "- In Scene 8, if you fail you go back to the last checkpoint (scene 4).\n"+
            "Click the menu button with your mouse to return"

        );
        instructions.setFont(new Font("Arial", Font.PLAIN, 16));
        instructions.setForeground(new Color(5, 74, 68)); // deep teal-green text
        instructions.setBackground(new Color(223, 245, 243));
        instructions.setEditable(false);
        instructions.setLineWrap(true);
        instructions.setWrapStyleWord(true);
        instructions.setMargin(new Insets(20, 30, 20, 30));

        // Scroll pane in case text is long
        JScrollPane scrollPane = new JScrollPane(instructions);
        scrollPane.setBorder(null);
        scrollPane.setBackground(new Color(223, 245, 243));

        // Back button to return to the menu
        JButton backButton = new JButton("Back to Menu");
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBackground(new Color(223, 245, 243));
        backButton.setForeground(new Color(5, 74, 68));
        backButton.setFocusPainted(false);
        backButton.setOpaque(true);
        backButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                new Menu(frame); // Assumes you have a Menu class
            }
        });

        // Add components to the panel
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);

        // Display panel on the frame
        frame.add(panel);
        frame.revalidate();
        frame.repaint();
    }
}
