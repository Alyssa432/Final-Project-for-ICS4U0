/*Glitchbreak: scene5 testing game choice 2
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene5C2 represents the scene where the character chooses to "Change Ways"
 * instead of jumping the fence. It includes a walking animation and a reflective dialogue.
 */
public class Scene5C2 extends JPanel {

   private int x = 0;                         // Tracks character x
   private int imageState = 1;                // Tracks animation frame (1 to 3)
   private BufferedImage walkRFoot, standLeft, walkLFoot, fence, background;
   private Timer walkTimer, dialogTimer;
   private boolean showDialogue;              // Whether dialogue should be shown

   /**
    * Constructor loads images and sets up animation and dialogue timers.
    */
   public Scene5C2() {
      setBackground(new Color(176, 231, 255)); // Sky-like background
      showDialogue = false;

      try {
         background = ImageIO.read(new File("background2.png"));     // Background image
         fence = ImageIO.read(new File("fence.png"));                // Fence in the scene
         walkRFoot = ImageIO.read(new File("walkRFoot.png"));        // Right foot forward
         standLeft = ImageIO.read(new File("standLeft.png"));        // Standing position
         walkLFoot = ImageIO.read(new File("walkLFoot.png"));        // Left foot forward
      } catch (IOException e) {
         e.printStackTrace();
      }

      // Timer to animate walking by updating position and frame every 200ms
      walkTimer = new Timer(200, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            x += 20;                    // Move character left
            imageState++;              // Cycle through animation frames
            if (imageState > 3) imageState = 1;
            repaint();                 // Redraw the scene
         }
      });

      // Timer to trigger dialogue after a delay (800ms)
      dialogTimer = new Timer(800, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            showDialogue = true;
            repaint();
         }
      });
      dialogTimer.setRepeats(false); // Only fire once
   }

   /**
    * Starts both timers: one for walking, one for delayed dialogue.
    */
   public void start() {
      walkTimer.start();
      dialogTimer.start();
   }

   /**
    * Stops both timers if needed.
    */
   public void stop() {
      walkTimer.stop();
      dialogTimer.stop();
   }

   /**
    * Paints the scene: background, character animation, and (if active) dialogue box.
    */
   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      g.drawImage(fence, 0, 0, 800, 600, null);      // Draw the fence
      g.drawImage(background, 0, 0, 800, 600, null); // Draw the background

      // Select current animation frame based on imageState
      BufferedImage currentImage;
      if (imageState == 1) {
         currentImage = walkLFoot;
      } else if (imageState == 2) {
         currentImage = standLeft;
      } else {
         currentImage = walkRFoot;
      }

      g.drawImage(currentImage, 200 - x, 200, 120, 200, null); // Draw character moving left

      // Draw dialogue box if it's time
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20); // Background for dialogue
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 14));
         g.drawString("You decide to walk on the grass, along the fence. No", 70, 470);
         g.drawString("one has ever walked on the grass before. It is pristine", 70, 495);
         g.drawString("and perfect and...", 70, 515);
         g.setColor(Color.RED);
         g.drawString("fake.", 250, 515);  // Emphasis on “fake.”
         g.setColor(Color.WHITE);
         g.drawString("But you keep going.", 300, 515);
         g.drawString("The fence must end somewhere, right?", 70, 535);
      }
   }

   /**
    * Main method to test Scene5C2 independently.
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene5C2 Test");
      Scene5C2 scene = new Scene5C2();
      frame.add(scene);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // trigger animation and dialogue
   }
}
