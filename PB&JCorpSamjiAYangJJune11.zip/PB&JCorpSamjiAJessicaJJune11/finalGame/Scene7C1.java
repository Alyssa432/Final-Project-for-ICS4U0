/*Glitchbreak: scene7 testing game choice 1
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene7C1 shows a character being caught by a robot AI just as they try to leave.
 */
public class Scene7C1 extends JPanel {

   // Images used in the scene
   private BufferedImage ch1, ch2, robot, robotTextBox, wall;

   // Timers to delay when the robot and dialogue appear
   private Timer robotTimer, dialogueTimer;

   // Control flags for rendering
   private boolean showRobot, showDialogue;

   /**
    * Constructor loads images, sets background, and initializes timers.
    */
   public Scene7C1() {
      setBackground(new Color(200, 200, 200));

      try {
         ch1 = ImageIO.read(new File("scene7C1Focused.png"));   // Normal character pose
         ch2 = ImageIO.read(new File("scene7C1Scared.png"));    // Scared character pose
         robotTextBox = ImageIO.read(new File("spiky.png"));    // Robot's speech box
         wall = ImageIO.read(new File("wearAndTearLol.png"));   // Background wall
         robot = ImageIO.read(new File("robot.png"));           // Robot image
      } catch (IOException e) {
         System.err.println("Error loading images: " + e.getMessage());
         e.printStackTrace();
      }

      // Show dialogue box 1 second after start
      dialogueTimer = new Timer(1000,
         e -> {
            showDialogue = true;
            repaint();
         });
      dialogueTimer.setRepeats(false);

      // Show robot 2.5 seconds after start
      robotTimer = new Timer(2500,
         e -> {
            showRobot = true;
            repaint();
         });
      robotTimer.setRepeats(false);
   }

   /**
    * Starts the scene animations and triggers.
    */
   public void start() {
      dialogueTimer.start();
      robotTimer.start();
   }

   /**
    * Stops all timers.
    */
   public void stop() {
      robotTimer.stop();
      dialogueTimer.stop();
   }

   /**
    * Draws the full scene, including background, character, robot, and dialogue.
    */
   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Draw background wall image
      if (wall != null) {
         g.drawImage(wall, 0, 0, 800, 600, null);
      }

      // Draw grey ground platform
      g.setColor(new Color(100, 100, 100));
      g.fillRect(0, 450, getWidth(), 150);

      // Draw character's default (focused) pose
      g.drawImage(ch1, 330, 280, 250, 300, null);

      // If robot has appeared:
      if (showRobot) {
         // White door frame where the robot emerges
         g.setColor(Color.WHITE);
         g.fillRect(80, 200, 150, 250);

         // Draw robot (or red box if image fails)
         if (robot != null) {
            g.drawImage(robot, 120, 180, 200, 300, null);
         } else {
            g.setColor(Color.RED);
            g.fillRect(120, 180, 200, 300);
         }

         // Swap to scared character pose
         g.drawImage(ch2, 330, 280, 250, 300, null);

         // Draw robot's speech bubble
         if (robotTextBox != null) {
            g.drawImage(robotTextBox, 120, 260, 200, 200, null);
         }

         // Robot saying "Halt!"
         g.setColor(Color.RED);
         g.setFont(new Font("Courier New", Font.BOLD, 30));
         g.drawString("Halt!", 182, 378);
      }

      // Dialogue narration text
      if (showDialogue) {
         // Black rounded textbox
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 500, 700, 80, 20, 20);

         // White text inside
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 14));
         g.drawString("Right when you think you're safe to leave, an AI robot appears,", 70, 535);
         g.drawString("catching you in the act!", 70, 550);

         // Dramatic red indicator
         g.setColor(Color.RED);
         g.fillRect(350, 490, 20, 10);
      }
   }

   /**
    * Main method to run the scene independently.
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene7C1 Test");
      Scene7C1 scene = new Scene7C1();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(scene);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // Trigger scene events
   }
}


