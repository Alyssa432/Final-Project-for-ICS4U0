/*Glitchbreak: Testing Game runner (Level 2)
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import javax.swing.*;
import java.awt.event.*;

/**
 * The Level2Runner class runs Level 2 of the game.
 * It controls the timing and order of scenes using a Timer.
 * It also handles choices made by the player to show different scenes.
 */
public class Level2Runner {
   /** Timer tick counter used to trigger scene transitions */
   private static int x = 0;

   /** Main game timer that controls scene progression */
   private static Timer timer;

   /** Tracks if the player has reached the alternate ending path */
   private static boolean reachedEnding2 = false;

   /** Tracks the first major choice the player made */
   private static boolean choice1Chosen = false;

   // Scene instances used in level 2
   private static Scene1T scene1;
   private static Scene2T scene2;
   private static Scene3T scene3;
   private static Scene4T scene4;
   private static Scene5C1 scene5C1;
   private static Scene5C2 scene5C2;
   private static Scene6C1 scene6C1;
   private static Scene6C2 scene6C2;
   private static Scene7C1 scene7C1;
   private static Scene7C2 scene7C2;
   private static Scene8 scene8;
   private static Scene9T scene9;
   private static Scene10T scene10;
   private static Scene11T scene11;

   /** Flags to ensure scenes 5–7 are started only once */
   private static boolean scene5Started = false;
   private static boolean scene6Started = false;
   private static boolean scene7Started = false;

   /**
    * Starts the level 2 gameplay by initializing scenes and starting the timer.
    * @param frame The main JFrame to add scenes to.
    */
   public static void startGame(JFrame frame) {
      // Reset control variables
      x = 0;
      scene5Started = false;
      scene6Started = false;
      scene7Started = false;
      reachedEnding2 = false;

      // Initialize all scenes
      scene1 = new Scene1T();
      scene2 = new Scene2T();
      scene3 = new Scene3T();
      scene4 = new Scene4T();
      scene5C1 = new Scene5C1();
      scene5C2 = new Scene5C2();
      scene6C1 = new Scene6C1();
      scene6C2 = new Scene6C2();
      scene7C1 = new Scene7C1();
      scene7C2 = new Scene7C2();
      scene8 = new Scene8();
      scene9 = new Scene9T();
      scene10 = new Scene10T();
      scene11 = new Scene11T();

      // Start with Scene 1
      frame.getContentPane().removeAll();
      frame.revalidate();
      frame.repaint();
      frame.add(scene1);
      frame.revalidate();
      frame.repaint();
      scene1.start();

      // Timer to control scene transitions based on tick count
      timer = new Timer(100, new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            x++;

            // Transition from Scene 1 to Scene 2
            if (x == 34) {
               scene1.stop();
               frame.remove(scene1);
               frame.add(scene2);
               frame.revalidate();
               frame.repaint();
               scene2.start();
            }

            // Scene 2 passed or restart from beginning
            else if (x == 148) {
               if (scene2.wasPassed()) {
                  scene2.stop();
                  frame.remove(scene2);
                  frame.add(scene3);
                  frame.revalidate();
                  frame.repaint();
                  scene3.start();
               } else {
                  timer.stop();
                  startGame(frame);
               }
            }

            // Transition from Scene 3 to Scene 4
            else if (x == 206) {
               scene3.stop();
               frame.remove(scene3);
               frame.add(scene4);
               frame.revalidate();
               frame.repaint();
               scene4.start();
            }

            // Handle Scene 5 based on choice made in Scene 4
            else if (!scene5Started && x >= 273 && x <= 278) {
               scene5Started = true;
               scene4.stop();
               frame.remove(scene4);

               if (scene4.isJumped()) {
                  frame.add(scene5C1);
                  choice1Chosen = true;
                  scene5C1.start();
               } else if (scene4.changedWays()) {
                  frame.add(scene5C2);
                  choice1Chosen = false;
                  scene5C2.start();
               }

               frame.revalidate();
               frame.repaint();
            }

            // Transition to Scene 6 based on previous path
            else if (!scene6Started && x == 338) {
               scene6Started = true;
               if (choice1Chosen) {
                  scene5C1.stop();
                  frame.remove(scene5C1);
                  frame.add(scene6C1);
               } else {
                  scene5C2.stop();
                  frame.remove(scene5C2);
                  frame.add(scene6C2);
                  scene6C2.start();
               }
               frame.revalidate();
               frame.repaint();
            }

            // Transition to Scene 7
            else if (!scene7Started && x == 405) {
               scene7Started = true;

               if (choice1Chosen) {
                  frame.remove(scene6C1);
                  frame.add(scene7C1);
                  reachedEnding2 = false;
                  scene7C1.start();
               } else {
                  scene6C2.stop();
                  frame.remove(scene6C2);
                  frame.add(scene7C2);
                  reachedEnding2 = true;
                  scene7C2.start();
               }

               frame.revalidate();
               frame.repaint();
            }

            // Branch depending on ending path after Scene 7
            else if (x == 448) {
               if (reachedEnding2) {
                  scene7C2.stop();
                  frame.remove(scene7C2);
                  timer.stop();
                  startGame(frame);
               } else {
                  scene7C1.stop();
                  frame.remove(scene7C1);
                  frame.add(scene8);
                  scene8.start();
                  frame.revalidate();
                  frame.repaint();
               }
            }

            // After Scene 8, restart or continue based on game over state
            else if (x == 652 && !reachedEnding2) {
               scene8.stop();
               frame.remove(scene8);
               if (scene8.isGameOver()) {
                  // Reinitialize scenes for replay
                  scene5Started = false;
                  scene6Started = false;
                  scene7Started = false;
                  choice1Chosen = false;

                  scene4 = new Scene4T();
                  scene5C1 = new Scene5C1();
                  scene5C2 = new Scene5C2();
                  scene6C1 = new Scene6C1();
                  scene6C2 = new Scene6C2();
                  scene7C1 = new Scene7C1();
                  scene7C2 = new Scene7C2();
                  scene8 = new Scene8();
                  scene9 = new Scene9T();
                  scene10 = new Scene10T();
                  scene11 = new Scene11T();

                  frame.add(scene4);
                  scene4.start();
                  x = 206; // Go back to scene 4
               } else {
                  frame.add(scene9);
                  scene9.start();
                  frame.revalidate();
                  frame.repaint();
               }
            }

            // Transition from Scene 9 to Scene 10
            else if (x == 709 && !reachedEnding2) {
               scene9.stop();
               frame.remove(scene9);
               frame.add(scene10);
               scene10.start();
               frame.revalidate();
               frame.repaint();
            }

            // Transition from Scene 10 to Scene 11
            else if (x == 776 && !reachedEnding2) {
               scene10.stop();
               frame.remove(scene10);
               frame.add(scene11);
               frame.revalidate();
               frame.repaint();
            }

            // Final ending transition back to menu
            else if (x == 843 && !reachedEnding2) {
               frame.remove(scene11);
               frame.revalidate();
               frame.repaint();
               timer.stop();
               frame.getContentPane().removeAll();
               new Menu(frame);
            }
         }
      });

      // Start the scene progression timer
      timer.start();
   }
}
