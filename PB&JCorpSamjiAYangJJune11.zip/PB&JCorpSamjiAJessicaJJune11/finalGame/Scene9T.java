/*Glitchbreak: scene9 testing game
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene9T is a JPanel that displays a scene with a sad robot,
 * some images, and a timed dialogue box that appears after 1 second.
 */
public class Scene9T extends JPanel {
   private BufferedImage sadRobot, pourWater, robotText, wall;
   // Images used in the scene

   private boolean showDialogue;
   // Controls when the dialogue box appears

   private Timer dialogTimer;
   // Timer that delays showing the dialogue box

   /**
    * Constructor for Scene9T.
    * Sets up background color, loads images,
    * and initializes the timer for dialogue display.
    */
   public Scene9T() {
      showDialogue = false; // dialogue hidden at start
      setBackground(new Color(200, 200, 200)); // background color

      try {
         // Load images from files
         pourWater = ImageIO.read(new File("pourWater.png"));
         wall = ImageIO.read(new File("wearAndTearLol.png"));
         sadRobot = ImageIO.read(new File("robotSad.png"));
         robotText = ImageIO.read(new File("spiky.png"));
      } catch (IOException e) {
         e.printStackTrace(); // print error if images fail to load
      }

      // Initialize a timer that fires once after 1 second (1000 ms)
      dialogTimer = new Timer(1000,
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               showDialogue = true; // show dialogue when timer triggers
               repaint(); // repaint panel to display dialogue box
            }
         });
      dialogTimer.setRepeats(false); // timer runs only once
   }

   /**
    * Starts the dialog timer so that the dialogue box appears after a delay.
    */
   public void start() {
      dialogTimer.start(); // start the timer to eventually show dialogue
   }

   /**
    * Stops the dialog timer if it needs to be stopped before showing dialogue.
    */
   public void stop() {
      dialogTimer.stop(); // stop the timer if needed
   }

   /**
    * Paints the scene including background, images, and dialogue box if triggered.
    * @param g The Graphics object used to draw on the panel.
    */
   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Draw background wall image to fill entire panel
      g.drawImage(wall, 0, 0, 800, 600, null);

      // Draw a gray ground/platform rectangle near bottom
      g.setColor(new Color(100, 100, 100));
      g.fillRect(0, 450, getWidth(), 150);

      // Draw the sad robot image at fixed position and size
      g.drawImage(sadRobot, 50, 300, 130, 200, null);
      // Draw the water pouring image overlapping the robot
      g.drawImage(pourWater, 100, 200, 240, 300, null);

      // If timer triggered, draw dialogue box and text
      if (showDialogue) {
         g.setColor(Color.BLACK);
         // Rounded rectangle background for dialogue
         g.fillRoundRect(50, 500, 700, 80, 20, 20);

         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 16));
         // Two lines of dialogue text inside the box
         g.drawString("When you reach the robot, you grab the", 70, 520);
         g.drawString("water out of a satchel and dump it on him. ", 70, 560);
      }
   }
}
   /**
    * The main method creates a window to display this scene.
    * @param args Command line arguments (not used).
    */

