// Glitchbreak: Scene3
// Jessica Yang and Alyssa Samji final ISP project
// Ms. Krasteva
// Jun 11, 2025

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Scene3 shows two characters on a sky-blue background with dialogue text.
 * It also has a “Return to Menu” button at the top right.
 */
public class Scene3 extends JPanel {
   /** Horizontal position for any animation (not used here yet) */
   private int x = 0;

   /** Images of the friend standing right, sassy face, and text box */
   private BufferedImage friendStandRight, faceForwardSassy, textBox;

   /**
    * Constructs the scene, loads images, and adds a transparent
    * “Return to Menu” button to the frame.
    *
    * @param frame the main game window
    */
   public Scene3(JFrame frame) {
      // Create a transparent button for returning to the menu
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);

      // Button action: remove this scene and show the menu
      returnButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               new Menu(frame);
            }
         });

      // Load images from files
      try {
         friendStandRight = ImageIO.read(new File("friendStandRight.png"));
         faceForwardSassy = ImageIO.read(new File("faceForwardSassy.png"));
         textBox = ImageIO.read(new File("TextBoxReverse.png"));
      } catch (IOException e) {
         // If images fail to load, do nothing here
      }
   }

   /**
    * Paints the background, characters, text box, dialogue text,
    * and the return button's outline and label.
    */
   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Set sky blue background color and fill background
      Color sky = new Color(206, 237, 250);
      g.setColor(sky);
      g.fillRect(0, 0, 800, 600);

      // Draw friend character on left side
      if (friendStandRight != null) {
         g.drawImage(friendStandRight, 100, 250, 200, 400, null);
      }

      // Draw dialogue text box near top center
      if (textBox != null) {
         g.drawImage(textBox, 250, 150, 300, 150, null);
      }

      // Draw dialogue text inside the box
      g.setColor(Color.BLACK);
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      g.setFont(serifFont);
      g.drawString("How strange!", 350, 200);
      g.drawString("I swear there was a road there. I", 300, 220);
      g.drawString("guess we'll go somewhere else!", 300, 240);

      // Draw sassy face character on the right side
      if (faceForwardSassy != null) {
         g.drawImage(faceForwardSassy, 505, 245, 200, 400, null);
      }

      // Draw the return button's background rectangle and label
      g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);

      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);

      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);
      g.drawString("Use mouse to click menu button", 585, 55);
   }
}
