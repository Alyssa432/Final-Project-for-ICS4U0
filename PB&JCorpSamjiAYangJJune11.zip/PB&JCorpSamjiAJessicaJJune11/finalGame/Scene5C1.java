/*Glitchbreak: scene5 testing game choice 1
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene5C1 represents the setting the player sees after choosing to "Jump" the fence.
 * The scene is bleak and gray, suggesting an old, broken-down environment.
 */
public class Scene5C1 extends JPanel {
   private BufferedImage ch1, wall;        // Character and wall images
   private boolean showDialogue;           // Controls whether dialogue is displayed
   private Timer dialogTimer;              // Delays when dialogue appears

   /**
    * Constructor sets up visuals and timer to reveal dialogue.
    */
   public Scene5C1() {
      showDialogue = false;
      setBackground(new Color(200, 200, 200)); // Neutral gray background

      try {
         ch1 = ImageIO.read(new File("standBack.png"));            // Character image
         wall = ImageIO.read(new File("wearAndTearLol.png"));      // Background wall
      } catch (IOException e) {
         e.printStackTrace();
      }

      // Timer that triggers the dialogue display after 1 second
      dialogTimer = new Timer(1000, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            showDialogue = true;
            repaint(); // Update screen to draw dialogue
         }
      });
      dialogTimer.setRepeats(false); // Trigger only once
   }

   /**
    * Starts the timer to show the dialogue.
    */
   public void start() {
      dialogTimer.start();
   }

   /**
    * Stops the timer in case it is still running.
    */
   public void stop() {
      dialogTimer.stop();
   }

   /**
    * Draws the scene: background, character, and (if active) dialogue box.
    */
   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      g.drawImage(wall, 0, 0, 800, 600, null); // Draw the worn-down background

      g.setColor(new Color(100, 100, 100));    // Darker ground
      g.fillRect(0, 450, getWidth(), 150);

      g.drawImage(ch1, 330, 300, 160, 300, null); // Draw the character

      // Show dialogue if timer has triggered it
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20); // Dialogue box
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 16));
         g.drawString("Beyond the fence, there is only concrete.", 70, 475);
         g.drawString("The grass has disappeared. The sky has disappeared.", 70, 500);
         g.drawString("You are now in an old, dilapidated room.", 70, 525);
      }
   }

   /**
    * Main method to test Scene5C1 independently.
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene5 choice 1 Test");
      Scene5C1 scene = new Scene5C1();
      frame.add(scene);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // Start the dialogue timer after showing the frame
   }
}
