/*Glitchbreak: Player Manager class
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Alyssa Samji
*/

import javax.swing.*;
import java.io.*;
import java.util.*;

/**
 * The PlayerManager class handles storing and retrieving the player's name.
 * It also keeps a list of the alphabet used for custom name sorting.
 */
public class PlayerManager {
    // The current player's name
    private static String playerName = null;

    // Alphabet list used for custom sorting (used in Leaderboard)
    private static final ArrayList<String> letters = new ArrayList<>(Arrays.asList(
        "A","B","C","D","E","F","G","H","I","J","K","L","M","N",
        "O","P","Q","R","S","T","U","V","W","X","Y","Z"));

    /**
     * Prompts the player to enter their name using a dialog box.
     * The name must not be blank or already taken (case-insensitive).
     *
     * @param frame The main game window for showing dialogs
     */
    public static void promptForName(JFrame frame) {
        // If name is already set, skip asking again
        if (playerName != null) return;

        while (true) {
            String input = JOptionPane.showInputDialog(frame, "Enter your name:");
            if (input == null || input.trim().equals("")) continue; // Retry if blank or canceled

            input = input.trim(); // Remove any extra spaces

            // Check if the name is already used
            if (isDuplicate(input)) {
                JOptionPane.showMessageDialog(frame, "That name is taken. Try another.");
            } else {
                playerName = input;
                saveName(input); // Save to file
                break;
            }
        }
    }

    /**
     * Checks if the given name already exists in the "players.txt" file.
     *
     * @param name The name to check
     * @return true if the name is already taken, false otherwise
     */
    private static boolean isDuplicate(String name) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("players.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equalsIgnoreCase(name)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException e) {
            // Fail silently if file can't be read
        }
        return false;
    }

    /**
     * Saves the player's name to "players.txt" (adds it to the end of the file).
     *
     * @param name The name to save
     */
    private static void saveName(String name) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter("players.txt", true));
            writer.println(name);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace(); // Show error if writing fails
        }
    }

    /**
     * Returns the name of the current player.
     *
     * @return The player's name
     */
    public static String getPlayerName() {
        return playerName;
    }

    /**
     * Returns the alphabet list (used for custom name sorting).
     *
     * @return An ArrayList of capital letters A-Z
     */
    public static ArrayList<String> getLetters() {
        return letters;
    }
}


// To learn ArrayAsList: https://www.geeksforgeeks.org/array-to-arraylist-conversion-in-java/

