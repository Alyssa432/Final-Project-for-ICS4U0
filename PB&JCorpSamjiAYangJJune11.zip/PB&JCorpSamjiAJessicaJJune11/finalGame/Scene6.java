// Alyssa Samji and Jessica Yang
// Scene6 of Game
// Final Project - GlitchBreak

/* GlitchBreak: Scene6
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
June 11, 2025

The following code was written by Alyssa Samji
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Scene6 class displays a scene where the characters react to the spa popping up.
 */
public class Scene6 extends JPanel {
   private int x = 0; // Counter for animation timing
   private BufferedImage friendStandBack, standBack, textBox, spa; // Images for characters, textbox, and spa
   private Timer timer; // Timer for animation updates

   /**
    * Constructor for Scene6.
    * Sets up the return button, loads images, and configures the timer.
    * @param frame The JFrame this panel is added to.
    */
   public Scene6(JFrame frame) {
      // Setup invisible return button
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);

      // Return button listener to stop timer and return to menu
      returnButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               timer.stop();
               new Menu(frame);
            }
         });

      // Load images from files
      try {
         friendStandBack = ImageIO.read(new File("friendStandBack.png"));
         standBack = ImageIO.read(new File("standBack.png"));
         textBox = ImageIO.read(new File("TextBoxReverse.png"));
         spa = ImageIO.read(new File("spa.png"));
      } catch (IOException e) {
         // Image loading failed; can be logged if needed
      }

      // Timer increments x and repaints every 150 ms
      timer = new Timer(150,
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               x += 1;
               repaint();
            }
         });
   }

   /**
    * Paints the scene with background, characters, text box, and "POP!" text.
    */
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      g.setFont(serifFont);

      // Draw sky and grass background
      Color sky = new Color(206, 237, 250);
      Color grass = new Color(170, 239, 80);
      g.setColor(sky);
      g.fillRect(0, 0, 800, 600);
      g.setColor(grass);
      g.fillRect(0, 300, 800, 300);

      // Draw road/ground as a gray polygon
      g.setColor(Color.GRAY);
      int[] yPoints = {300, 300, 600, 600};
      int[] xPoints = {300, 500, 800, 0};
      g.fillPolygon(xPoints, yPoints, 4);

      // Draw return to menu button background
      g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);
      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);

      // Draw return to menu text
      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);
      g.drawString("Use mouse to click menu button", 585, 55);

      // Draw spa building
      g.drawImage(spa, 200, 50, 400, 300, null);

      // Draw POP! effect in red
      g.setColor(Color.RED);
      g.setFont(new Font("Serif", Font.BOLD, 50));
      g.drawString("POP!", 650, 300);

      // Draw characters from the back
      g.drawImage(standBack, 505, 245, 200, 400, null);
      g.drawImage(friendStandBack, 100, 260, 200, 400, null);

      // Draw textbox and character reaction
      g.drawImage(textBox, 600, 150, 160, 150, null);
      g.setFont(serifFont);
      g.setColor(Color.BLACK);
      g.drawString("What the", 635, 210);
      g.drawString("heck?!", 645, 230);
   }

   /** Starts the animation timer. */
   public void start() {
      timer.start();
   }

   /** Stops the animation timer. */
   public void stop() {
      timer.stop();
   }
}
