/*
 * GlitchBreak: Scene7
 * Jessica Yang and Alyssa Samji final ISP project
 * Ms. Krasteva
 * Jun 11, 2025
 *
 * The following code was written by Alyssa Samji
 *
 * This class displays the final scene of the game showing the robots and AI image
 * along with a message on screen. It also includes an invisible return button
 * to navigate back to the menu.
 */

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Scene7 class displays the final scene with robots and AI message.
 */
public class Scene7 extends JPanel {
   private BufferedImage robotsAI; // Image of robots and AI

   /**
    * Constructor for Scene7.
    * Adds an invisible return button and loads the robotsAI image.
    * @param frame The JFrame this panel is added to.
    */
   public Scene7(JFrame frame) {
      // Setup invisible return button in top-right corner
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);
  
      // Return button listener stops Level1Runner and returns to menu
      returnButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               Level1Runner.stop();  // Stop any running animation or game logic in Level1Runner
               new Menu(frame);       // Return to menu screen
            }
         });
    
      // Load robotsAI image from file
      try {
         robotsAI = ImageIO.read(new File("robotsAI.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   /**
    * Paints the scene including the robotsAI image, return button, and text.
    */
   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      g.setFont(serifFont);
      g.setColor(Color.BLACK);
     
      // Draw the robots and AI image as background
      g.drawImage(robotsAI, 0, 0, 800, 600, null);
    
      // Draw return button background and border
      g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);
  
      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);
  
      // Draw return button text
      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);
    
      // Draw the message text on screen
      g.setFont(new Font("Serif", Font.BOLD, 15));
      g.setColor(Color.BLACK);
      g.drawString("We changed their words and path,", 290, 100);
      g.drawString("but nobody suspects a thing.", 290, 120);
      g.drawString("AI rules. Hahahaha!", 290, 140);
   }
}

/**
 * The GUI Tutorials did not explicitly teach me how to move pictures. I used information
 * that I learned from those tutorials, like about JPanel along with my knowledge from
 * Grade 11 to accomplish movement. For the JPanels, I had to research a way to iterate/
 * time the movement. That is why I used the resource below as it taught me about Swing
 * Timer.
 * https://stackoverflow.com/questions/32753169/how-to-use-a-swing-timer-with-jpanel
 */
