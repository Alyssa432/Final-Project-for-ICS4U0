/*Glitchbreak: Learning Game runner
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Alyssa Samji
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * The Level1Runner class controls the flow of Level 1 in the game.
 * It switches between scenes using a timer.
 */
public class Level1Runner {
   // Keeps track of how many timer steps have passed
   private static int x = 0;

   // The timer used to move between scenes
   private static Timer timer;

   /**
    * Starts Level 1 by showing each scene in order.
    * This method uses a timer to switch scenes at the right times.
    *
    * @param frame the main game window
    */
   public static void starts(JFrame frame) {
      // Clear the window before starting
      frame.getContentPane().removeAll();
      frame.revalidate();
      frame.repaint();

      // Create all the scenes for Level 1
      Scene1 scene1 = new Scene1(frame);
      Scene2 scene2 = new Scene2(frame);
      Scene3 scene3 = new Scene3(frame);
      Scene4 scene4 = new Scene4(frame);
      Scene5 scene5 = new Scene5(frame);
      Scene6 scene6 = new Scene6(frame);
      Scene7 scene7 = new Scene7(frame);

      // Show the first scene
      frame.getContentPane().add(scene1);
      scene1.start();
      frame.revalidate();
      frame.repaint();

      // Start the timer to control scene changes
      timer = new Timer(150, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            x++;

            if (x == 66) {
               scene1.stop();
               frame.getContentPane().remove(scene1);
               frame.add(scene2);
            } else if (x == 100) {
               frame.remove(scene2);
               frame.add(scene3);
            } else if (x == 134) {
               frame.remove(scene3);
               frame.add(scene4);
               scene4.start();
            } else if (x == 200) {
               scene4.stop();
               frame.remove(scene4);
               frame.add(scene5);
               scene5.start();
            } else if (x == 240) {
               scene5.stop();
               frame.remove(scene5);
               frame.add(scene6);
               scene6.start();
            } else if (x == 280) {
               scene6.stop();
               frame.remove(scene6);
               frame.add(scene7);
            }
            else if (x == 290){
               timer.stop();
               frame.getContentPane().removeAll();
               new Menu(frame);
               }

            frame.revalidate();
            frame.repaint();
         }
      });

      timer.start();
   }

   /**
    * Stops the timer and pauses Level 1.
    */
   public static void stop() {
      timer.stop();
   }
}
