/*Glitchbreak: Game Launcher
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Alyssa Samji
*/

import javax.swing.JFrame;

/**
 * This class starts the GlitchBreak game.
 * It opens the game window and shows the menu.
 */
public class GameLauncher {

    /**
     * This is the main method that runs when the game starts.
     * It creates the window and shows the menu screen.
     *
     * @param args
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("GlitchBreak");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        new Menu(frame);
    }
}
