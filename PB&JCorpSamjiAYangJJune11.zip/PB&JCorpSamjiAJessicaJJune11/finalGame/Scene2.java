// Alyssa Samji and Jessica Yang
// Scene 2 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Scene2 shows a brick-wall background with a short message.
 * It also includes a “Return to Menu” button.
 */
public class Scene2 extends JPanel {
   /** Background image of the brick wall */
   private BufferedImage brickWall;

   /**
    * Builds the scene, loads the brick-wall image, and adds
    * a “Return to Menu” button to the given frame.
    *
    * @param frame the main game window
    */
   public Scene2(JFrame frame) {
      // button to return to menu
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);

      // Go back to menu when the button is clicked with mouse
      returnButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               new Menu(frame);
            }
         });

      // Load the brick-wall image
      try {
         brickWall = ImageIO.read(new File("brickWall.png"));
      } catch (IOException e) {
         // Image failed to load; leave brickWall null
      }
   }

   /**
    * Draws the brick wall, the “Return to Menu” button outline,
    * and a short caption on the wall.
    */
   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Draw background brick wall
      g.drawImage(brickWall, 0, 0, 800, 600, null);        

      // Caption background box
      g.setColor(Color.WHITE);
      g.fillRect(200, 450, 400, 100);

      // Draw invisible button’s outline and label
      g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);

      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);

      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);
      g.drawString("Use mouse to click menu button", 585, 55);

      // Caption text
      Font serifFont = new Font("Serif", Font.BOLD, 25);
      g.setFont(serifFont);
      g.setColor(Color.BLACK);

      g.drawString("Suddenly a brick wall", 295, 495);
      g.drawString("appears.", 350, 515);
   }
}
