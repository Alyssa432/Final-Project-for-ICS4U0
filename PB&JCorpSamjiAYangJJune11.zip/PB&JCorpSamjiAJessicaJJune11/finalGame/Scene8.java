/*Glitchbreak: scene8 testing game
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang and Alyssa Samji
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import java.io.*;
import javax.imageio.ImageIO;

public class Scene8 extends JPanel implements ActionListener, KeyListener {
   private Timer timer;
   private int playerX = 100;
   private int playerY = 250;
   private int playerHeight = 120;
   private int playerWidth = 60;
   private int groundY = 250;
   private String state = "stand"; // can be "stand", "jump", or "duck"
   private int jumpVelocity = 0;
   private boolean gameOver = false;
   private boolean win = false;

   private int obstaclesPassed = 0; // how many obstacles have been successfully passed
   private final int totalObstaclesToWin = 10; // number of obstacles required to win

   private ArrayList<Rectangle> obstacles = new ArrayList<Rectangle>();
   private int spawnCounter = 0; // used to control obstacle spawning
   private Random rand = new Random();

   private BufferedImage standRight;
   private BufferedImage robotLeft;

   private int robotWidth = 100;
   private int robotHeight = 200;
   private int robotX = 650;
   private int robotY = groundY - (robotHeight - 50); // align robot's bottom to ground

   /**
    * Constructor for Scene8 sets up the panel and loads images.
    */
   public Scene8() {
      setFocusable(true);
      setBackground(new Color(230, 230, 230));
      try {
         standRight = ImageIO.read(new File("standRight.png"));
         robotLeft = ImageIO.read(new File("robotLeft.png"));
      } catch (IOException e) {
         System.out.println("Error loading image: " + e.getMessage());
      }
   }

   /**
    * Starts the game by adding key listener and starting the timer.
    */
   public void start() {
      addKeyListener(this);
      requestFocusInWindow();
      timer = new Timer(20, this);
      timer.start();
   }

   /**
    * Stops the game timer.
    */
   public void stop() {
      timer.stop();
   }

   /**
    * This method is called every time the timer ticks (every 20 ms).
    * It updates the game state: player movement, obstacles, collision checks.
    */
   public void actionPerformed(ActionEvent e) {
      if (gameOver || win) {
         timer.stop();
         return;
      }
  
      // Handle jumping
      if (state.equals("jump")) {
         playerY += jumpVelocity;
         jumpVelocity += 1; // gravity effect
         if (playerY >= groundY) {
            playerY = groundY;
            state = "stand";
            jumpVelocity = 0;
         }
      }
  
      // Handle ducking by changing player height
      if (state.equals("duck")) {
         playerHeight = 40;
      } else {
         playerHeight = 120;
      }
  
      // Move obstacles left and count passed ones
      for (int i = 0; i < obstacles.size(); i++) {
         Rectangle obs = obstacles.get(i);
         obs.x -= 5;
         if (obs.x + obs.width < 0) {
            obstacles.remove(i);
            i--;
            obstaclesPassed++;
         }
      }
  
      // Spawn new obstacles randomly after some time
      spawnCounter++;
      if (spawnCounter > 70 && obstaclesPassed < totalObstaclesToWin) {
         spawnCounter = 0;
         boolean high = rand.nextBoolean();
         int obsY = high ? groundY - 55 : groundY;
         int spawnX = robotX - 40;
         obstacles.add(new Rectangle(spawnX, obsY, 40, 40));
      }
  
      // Move player forward after passing all obstacles
      if (obstaclesPassed >= totalObstaclesToWin) {
         playerX += 3;
      }
  
      // Check for collisions with obstacles
      Rectangle playerRect = new Rectangle(playerX, playerY + (50 - playerHeight), playerWidth, playerHeight);
      for (Rectangle obs : obstacles) {
         Rectangle obsRect = new Rectangle(obs.x, obs.y + (50 - obs.height), obs.width, obs.height);
     
         if (playerRect.intersects(obsRect)) {
            boolean fromBack = (playerX + playerWidth) <= obs.x;
            if (!fromBack) {
               gameOver = true;
               repaint();
               return;
            }
         }
      }
  
      // Check if player reached the robot to win
      if (obstaclesPassed >= totalObstaclesToWin) {
         Rectangle robotRect = new Rectangle(robotX, robotY, robotWidth, robotHeight);
         if (playerRect.intersects(robotRect)) {
            win = true;
         }
      }
  
      repaint();
   }
  
   public boolean isGameOver() {
      return gameOver;
   }

   /**
    * Paints the game objects (player, obstacles, robot, ground) on the panel.
    */
public void paintComponent(Graphics g) {
    super.paintComponent(g);

    // Draw instructions in the top-left corner
    g.setColor(Color.BLACK);
    g.setFont(new Font("Arial", Font.PLAIN, 14));
    g.drawString("How to play:", 10, 20);
    g.drawString("- UP arrow: Jump", 10, 40);
    g.drawString("- DOWN arrow: Duck", 10, 60);

    if (gameOver) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.RED);
        g.setFont(new Font("Courier New", Font.BOLD, 36));
        g.drawString("The AI caught you! Fail!", 120, 150);
        return;
    }

    if (win) {
        g.setFont(new Font("Courier New", Font.BOLD, 36));
        g.drawString("You reached the robot! You win!", 100, 150);
        return;
    }

    // Draw ground
    g.setColor(Color.GRAY);
    g.fillRect(0, groundY + 40, getWidth(), 400);

    // Draw robot
    if (robotLeft != null) {
        g.drawImage(robotLeft, robotX, robotY, robotWidth, robotHeight, null);
    } else {
        g.setColor(Color.BLUE);
        g.fillRect(robotX, robotY, robotWidth, robotHeight);
    }

    // Draw player
    if (standRight != null) {
        g.drawImage(standRight, playerX, playerY + (50 - playerHeight), playerWidth, playerHeight, null);
    } else {
        g.setColor(Color.GREEN);
        g.fillRect(playerX, playerY + (50 - playerHeight), playerWidth, playerHeight);
    }

    // Draw obstacles
    g.setColor(Color.RED);
    for (Rectangle obs : obstacles) {
        g.fillRect(obs.x, obs.y + (50 - obs.height), obs.width, obs.height);
    }
}


   /**
    * Called when a key is pressed.
    * Handles jump and duck actions.
    */
   public void keyPressed(KeyEvent e) {
      if (gameOver || win)
         return;
  
      if (e.getKeyCode() == KeyEvent.VK_UP && state.equals("stand")) {
         state = "jump";
         jumpVelocity = -16;
      }
  
      if (e.getKeyCode() == KeyEvent.VK_DOWN && state.equals("stand")) {
         state = "duck";
      }
   }

   /**
    * Called when a key is released.
    * Stops ducking when down arrow is released.
    */
   public void keyReleased(KeyEvent e) {
      if (gameOver || win)
         return;
  
      if (e.getKeyCode() == KeyEvent.VK_DOWN && state.equals("duck")) {
         state = "stand";
      }
   }

   /**
    * Called when a key is typed (not used here).
    */
   public void keyTyped(KeyEvent e) {}

   /**
    * Main method to create the game window and start the game.
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene8 - T-Rex Style Game");
      Scene8 scene8 = new Scene8();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(800, 600);
      frame.setResizable(false);
      frame.add(scene8);
      frame.setLocationRelativeTo(null);
      frame.setVisible(true);
      scene8.start();
   }
}
