/* Glitchbreak: scene10 testing game
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Alyssa Samji
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * Scene11T is a JPanel that displays the character waking up in a pod.
 */
public class Scene11T extends JPanel {
   private BufferedImage pod, faceForwardSassy;
   // Images for the pod and character face

   /**
    * Constructor loads images and sets the background color.
    */
   public Scene11T() {
      setBackground(Color.GRAY); // Set background color of the panel

      try {
         // Load images from files
         pod = ImageIO.read(new File("pod.png"));
         faceForwardSassy = ImageIO.read(new File("faceForwardSassy.png"));
      } catch (IOException e) {
         e.printStackTrace(); // Print error if images cannot be loaded
      }
   }

   /**
    * Paints the panel by drawing the pod and character images.
    * @param g Graphics object used to draw on the panel
    */
   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Draw the character image in front, positioned at (300, 200) with size 200x400
      g.drawImage(faceForwardSassy, 300, 200, 200, 400, null);

      // Draw the pod image behind the character, positioned at (50, 20) with size 700x800
      g.drawImage(pod, 50, 20, 700, 800, null);
   }

   /**
    * Main method creates a window to display the Scene11T panel.
    * @param args Command line arguments (not used)
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene11T");
      frame.setSize(800, 600);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setContentPane(new Scene11T()); // Add Scene11T panel as the frame’s content
      frame.setVisible(true);
   }
}

