/* Glitchbreak: Menu
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * The Menu class creates the main menu screen for the game.
 * It includes buttons to start Level 1, Level 2, view the leaderboard, or exit the game.
 */
public class Menu {
   private JPanel menuPanel;

   /**
    * Constructor: Builds the menu screen and adds it to the given frame.
    *
    * @param frame the main game window
    */
   public Menu(JFrame frame) {
      // Create the main panel for the menu
      menuPanel = new JPanel(new GridBagLayout());
      menuPanel.setBackground(new Color(242, 218, 241)); // Light pink background

      // Ask the player to enter their name before continuing
      PlayerManager.promptForName(frame);

      // Load and scale the background image
      ImageIcon backgroundImg = new ImageIcon("glitchBreak.png");
      Image temp = backgroundImg.getImage();
      Image tempScaled = temp.getScaledInstance(800, 580, Image.SCALE_SMOOTH);
      backgroundImg = new ImageIcon(tempScaled);

      // Create a label to hold the background image
      JLabel backgroundLabel = new JLabel(backgroundImg);
      backgroundLabel.setLayout(new GridBagLayout()); // Allow overlaying buttons

      // Create a transparent panel to hold buttons + instruction label
      JPanel buttonPanel = new JPanel(new GridLayout(6, 1, 0, 10)); // 5 buttons + instruction
      buttonPanel.setOpaque(false); // Transparent background

      // Create all the buttons
      JButton level1Button = new JButton("Level 1");
      JButton level2Button = new JButton("Level 2");
      JButton instructionsButton = new JButton("Instructions");
      JButton leaderboardButton = new JButton("Leaderboard");
      JButton exitButton = new JButton("Exit");

      // Instruction label (at the bottom)
      JLabel instructionLabel = new JLabel("Use mouse to navigate menu");
      instructionLabel.setHorizontalAlignment(SwingConstants.CENTER);
      instructionLabel.setForeground(Color.BLACK);
      instructionLabel.setFont(new Font("Arial", Font.BOLD, 16));

      // Add buttons and label to the panel
      buttonPanel.add(level1Button);
      buttonPanel.add(level2Button);
      buttonPanel.add(instructionsButton);
      buttonPanel.add(leaderboardButton);
      buttonPanel.add(exitButton);
      buttonPanel.add(instructionLabel);

      // Place the button panel on the background
      backgroundLabel.add(buttonPanel);
      menuPanel.add(backgroundLabel);

      // Add menu to frame
      frame.getContentPane().add(menuPanel);
      frame.revalidate();
      frame.repaint();

      // Button Actions
      level1Button.addActionListener(e -> {
         frame.getContentPane().removeAll();
         Level1Runner.starts(frame);
      });

      level2Button.addActionListener(e -> {
         frame.getContentPane().removeAll();
         Level2Runner.startGame(frame);
      });

      instructionsButton.addActionListener(e -> {
         frame.getContentPane().removeAll();
         Instructions.starts(frame);
      });

      leaderboardButton.addActionListener(e -> {
         frame.getContentPane().removeAll();
         Leaderboard.starts(frame);
      });

      exitButton.addActionListener(e -> System.exit(0));
   }
}
