/*Glitchbreak: scene6 testing game choice 1
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene6C1 represents a simple visual scene where a large button
 * appears on top of a worn wall background.
 */
public class Scene6C1 extends JPanel {
   private BufferedImage button, wall; // Images for the button and the wall background

   /**
    * Constructor loads images and sets the background color.
    */
   public Scene6C1() {
      setBackground(new Color(200, 200, 200)); // Gray background before images are drawn

      try {
         // Load button image and wall background from files
         button = ImageIO.read(new File("buttonOfDoom.png"));
         wall = ImageIO.read(new File("wearAndTearLol.png"));
      } catch (IOException e) {
         // Print stack trace if image loading fails
         e.printStackTrace();
      }
   }

   /**
    * Paints the wall background and the button on the panel.
    */
   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Draw wall background filling the panel
      g.drawImage(wall, 0, 0, 1000, 800, null);

      // Draw large button in the upper-middle of the screen
      g.drawImage(button, 200, 100, 400, 400, null);
   }

   /**
    * Main method to test Scene6C1 independently.
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene6 choice 1 Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(new Scene6C1());         // Add this scene to the frame
      frame.setSize(800, 600);           // Set window size
      frame.setVisible(true);            // Display the window
   }
}

