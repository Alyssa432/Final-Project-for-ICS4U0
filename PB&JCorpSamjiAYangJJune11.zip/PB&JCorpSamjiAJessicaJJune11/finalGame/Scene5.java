/**Alyssa Samji and Jessica Yang
Scene 5 of Game - GlitchBreak
Final Project - ICS4U
Ms. Krasteva
June 11, 2025
*/
// The following code was written by Alyssa Samji

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Scene5 class displays a scene where two characters plan to go to a spa.
 * After a short delay, the spa image and a "POP!" text appear.
 * Includes a return button to go back to the main menu.
 */
public class Scene5 extends JPanel {
   private int x = 0;  // Counter to track animation progress
   private BufferedImage friendStandRight, standLeft, textBox, spa;  // Images for characters, textbox, and spa
   private Timer timer;  // Timer to control animation

   /**
    * Constructor for Scene5.
    * Sets up the return button, loads images, and configures the timer.
    * @param frame The JFrame this panel is added to.
    */
   public Scene5(JFrame frame) {
      // Setup invisible return button
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);
   
      // ActionListener for return button to stop timer and return to menu
      returnButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               timer.stop();
               new Menu(frame);
            }
         });

      // Load images from files
      try {
         friendStandRight = ImageIO.read(new File("friendStandRight.png"));
         standLeft = ImageIO.read(new File("standLeft.png"));
         textBox = ImageIO.read(new File("TextBoxReverse.png"));
         spa = ImageIO.read(new File("spa.png"));
      } catch (IOException e) {
         // Could log error here if desired
      }

      // Timer updates x and repaints every 150 ms
      timer = new Timer(150,
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               x += 1;  // Increment counter
               repaint();
            }
         });
   }

   /**
    * Paints the scene.
    * Draws background, characters, text box, return button,
    * and displays the spa scene after a delay with "POP!".
    * @param g the Graphics object used for drawing
    */
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      g.setFont(serifFont);

      // Draw sky and grass background
      Color sky = new Color(206, 237, 250);
      Color grass = new Color(170, 239, 80);
      g.setColor(sky);
      g.fillRect(0, 0, 800, 600);
      g.setColor(grass);
      g.fillRect(0, 300, 800, 300);

      // Draw gray polygon for ground/road
      g.setColor(Color.GRAY);
      int[] yPoints = {300, 300, 600, 600};
      int[] xPoints = {300, 500, 800, 0};
      g.fillPolygon(xPoints, yPoints, 4);
         
      // Draw characters and textbox
      g.drawImage(friendStandRight, 100, 250, 200, 400, null);  
      g.drawImage(textBox, 250, 150, 160, 150, null);
      g.setColor(Color.BLACK);
      g.drawString("Let's go", 310, 215);
      g.drawString("to the spa!", 300, 235);
      g.drawImage(standLeft, 505, 245, 200, 400, null);
     
      // Draw return button background, border, and text
      g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);
      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);
      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);
      g.drawString("Use mouse to click menu button", 585, 55);

      // After counter x > 10, redraw scene with spa image and POP! text
      if (x > 10){
         g.setColor(sky);
         g.fillRect(0, 0, 800, 600);
         g.setColor(grass);
         g.fillRect(0, 300, 800, 300);

         g.setColor(new Color(220, 220, 220));
         g.fillRect(650, 10, 130, 30);
         g.setColor(Color.BLACK);
         g.drawRect(650, 10, 130, 30);
         g.setFont(new Font("SansSerif", Font.PLAIN, 14));
         g.drawString("Return to Menu", 660, 30);
         g.drawString("Use mouse to click menu button", 585, 55);

         g.setColor(Color.GRAY);
         int[] yPoints2 = {300, 300, 600, 600};
         int[] xPoints2 = {300, 500, 800, 0};
         g.fillPolygon(xPoints2, yPoints2, 4);
         g.drawImage(spa, 200, 50, 400, 300, null);
         g.drawImage(friendStandRight, 100, 250, 200, 400, null);  
         g.drawImage(textBox, 250, 150, 160, 150, null);
         g.setColor(Color.BLACK);
         g.drawString("Let's go", 310, 215);
         g.drawString("to the spa!", 300, 235);
         g.drawImage(standLeft, 505, 245, 200, 400, null);

         // Draw "POP!" text in red, large font
         g.setColor(Color.RED);
         g.setFont(new Font("Serif", Font.BOLD, 50));
         g.drawString("POP!", 650, 300);
      }
   }

   /**
    * Starts the animation timer.
    */
   public void start() {
      timer.start();
   }

   /**
    * Stops the animation timer.
    */
   public void stop(){
      timer.stop();
   }
}
