/** GlitchBreak: Scene 4
Jessica Yang and Alyssa Samji
Final Project - GlitchBreak
Ms. Krasteva
Jun 11, 2025
*/

// The following code was written by Alyssa Samji

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Scene4 displays an animated scene where the player and their friend
 * walk left across the screen. A thought bubble with dialogue appears
 * once they've passed a certain point.
 */
public class Scene4 extends JPanel {
   /** Controls how far characters have walked left */
   private int x = 0;
   /** Tracks which animation frame to display */
   private int imageState = 1;
   /** Timer that drives animation */
   private Timer timer;

   /** Character image states */
   private BufferedImage walkRFoot, standLeft, walkLFoot;
   private BufferedImage friendStandLeft, friendWalkRFoot, friendWalkLFoot;
   private BufferedImage thinking;

   /**
    * Constructs Scene4, loading images and setting up the return button and animation.
    * @param frame the main game window
    */
   public Scene4(JFrame frame) {
      // Create transparent "Return to Menu" button
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);

      // Return to Menu when clicked
      returnButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            frame.getContentPane().removeAll();
            timer.stop();
            new Menu(frame);
         }
      });

      // Load all required images
      try {
         walkRFoot = ImageIO.read(new File("walkRFoot.png"));
         standLeft = ImageIO.read(new File("standLeft.png"));
         walkLFoot = ImageIO.read(new File("walkLFoot.png"));
         friendStandLeft = ImageIO.read(new File("friendStandLeft.png"));
         friendWalkRFoot = ImageIO.read(new File("friendWalkRFoot.png"));
         friendWalkLFoot = ImageIO.read(new File("friendWalkLFoot.png"));
         thinking = ImageIO.read(new File("thinking.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }

      // Timer to update animation every 150 milliseconds
      timer = new Timer(150, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            x += 20;
            imageState++;
            if (imageState > 3) imageState = 1;
            repaint();
         }
      });
   }

   /**
    * Paints the animated scene, including characters and thought bubble.
    */
   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Set background to sky blue
      g.setColor(new Color(206, 237, 250));
      g.fillRect(0, 0, getWidth(), 400);

      // Draw Return to Menu button background
      g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);
      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);
      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);
      g.drawString("Use mouse to click menu button", 585, 55);

      // Select animation frame
      BufferedImage currentPlayerImage, currentFriendImage;
      if (imageState == 1) {
         currentPlayerImage = walkLFoot;
         currentFriendImage = friendStandLeft;
      } else if (imageState == 2) {
         currentPlayerImage = standLeft;
         currentFriendImage = friendWalkRFoot;
      } else {
         currentPlayerImage = walkRFoot;
         currentFriendImage = friendWalkLFoot;
      }

      // Draw characters walking to the left
      g.drawImage(currentFriendImage, 920 - x, 200, 150, 240, null);
      g.drawImage(currentPlayerImage, 845 - x, 200, 150, 240, null);

      // Draw thought bubble and text if characters are far enough left
      if (x > 200) {
         g.setFont(new Font("Serif", Font.BOLD, 15));
         g.setColor(Color.BLACK);
         g.drawImage(thinking, 645 - x, 150, 200, 100, null);
         g.drawString("Did they not", 700 - x, 180);
         g.drawString("see the brick wall?", 685 - x, 200);
      }
   }

   /** Starts the animation */
   public void start() {
      timer.start();
   }

   /** Stops the animation */
   public void stop() {
      timer.stop();
   }
}
