
/*Glitchbreak: Leaderboard
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Alyssa Samji
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

/**
 * The Leaderboard class shows a list of player names
 * from a file and displays them in order.
 */
public class Leaderboard {

    /**
     * Starts the leaderboard screen in the given frame.
     * It reads names from a file, sorts them, and shows them on the screen.
     *
     * @param frame the game window where the leaderboard will be shown
     */
    public static void starts(JFrame frame) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(230, 230, 250));
        JTextArea leaderboardText = new JTextArea();
        leaderboardText.setEditable(false);
        leaderboardText.setFont(new Font("Courier New", Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(leaderboardText);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    frame.getContentPane().removeAll();
                    new Menu(frame);
                }
            }
        );

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);

        ArrayList<String> names = readNamesFromFile();
        sortNames(names);
        for (String name : names) {
            leaderboardText.append(name + "\n");
        }

        frame.getContentPane().add(panel);
        frame.revalidate();
        frame.repaint();
    }

    /**
     * Reads player names from the file "players.txt".
     *
     * @return a list of names from the file
     */
    private static ArrayList<String> readNamesFromFile() {
        ArrayList<String> names = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("players.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                names.add(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return names;
    }

    /**
     * Sorts the list of names based on custom letter order from PlayerManager.
     *
     * @param names the list of names to sort
     */
    private static void sortNames(ArrayList<String> names) {
        boolean swapped;
        do {
            swapped = false;
            for (int i = 0; i < names.size() - 1; i++) {
                String temp1 = names.get(i);
                String temp2 = names.get(i + 1);
                if (compareNames(temp1, temp2) > 0) {
                    names.set(i, temp2);
                    names.set(i + 1, temp1);
                    swapped = true;
                }
            }
        } while (swapped);
    }

    /**
     * Compares two names using a custom order from PlayerManager.getLetters().
     *
     * @param a the first name
     * @param b the second name
     * @return a negative number if a comes before b, positive if after, or 0 if equal
     */
    private static int compareNames(String a, String b) {
        int index = 0;
        while (index < a.length() && index < b.length()) {
            String letterA = a.substring(index, index + 1).toUpperCase();
            String letterB = b.substring(index, index + 1).toUpperCase();

            int posA = PlayerManager.getLetters().indexOf(letterA);
            int posB = PlayerManager.getLetters().indexOf(letterB);

            if (posA != posB) return posA - posB;
            index++;
        }
        return a.length() - b.length();
    }
}
