/*Glitchbreak: scene10 testing game
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Alyssa Samji
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene10T is a JPanel that shows the button to escape,
 * and an animated arm that moves when the button is clicked with the mouse.
 */
public class Scene10T extends JPanel {
   private BufferedImage button, wall, arm;
   // Images for background, button, and arm

   private Timer timer;
   // Timer to animate arm movement

   private int armX = -300;
   // Starting x-position of the arm (off-screen to the left)

   private JButton bigButton;
   // Invisible button placed over the button image for user clicks

   /**
    * Constructor sets up the panel, loads images, creates
    * a transparent button for interaction, and initializes the animation timer.
    */
   public Scene10T() {
      setLayout(null); // Use absolute positioning for components
      setBackground(new Color(200, 200, 200)); // Panel background color

      try {
         // Load images from files
         button = ImageIO.read(new File("buttonOfDoom.png"));
         wall = ImageIO.read(new File("wearAndTearLol.png"));
         arm = ImageIO.read(new File("arm.png"));
      } catch (IOException e) {
         e.printStackTrace(); // Print error if image loading fails
      }

      // Create a transparent JButton positioned over the button image for interaction
      bigButton = new JButton("");
      bigButton.setFont(new Font("SansSerif", Font.BOLD, 24));
      bigButton.setBounds(338, 229, 102, 102); // Set position and size to cover button image
      bigButton.setOpaque(false);
      bigButton.setContentAreaFilled(false);
      bigButton.setBorderPainted(false);

      // When button is clicked, start the arm animation timer
      bigButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            timer.start();
         }
      });

      add(bigButton); // Add button to the panel

      // Timer fires every 60 milliseconds to update arm position and repaint
      timer = new Timer(60, new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            armX += 20; // Move arm 20 pixels to the right each tick
            if (armX >= 300) { // Stop animation when arm reaches x=300
               timer.stop();
            }
            repaint(); // Repaint panel to show updated arm position
         }
      });
   }

   /**
    * Paints the panel by drawing the background, button image, and arm at its current position.
    * @param g Graphics object used to draw on the panel.
    */
@Override
public void paintComponent(Graphics g) {
   super.paintComponent(g);

   // Draw the background wall filling the panel area
   g.drawImage(wall, 0, 0, 1000, 800, null);

   // Draw the button image centered on panel
   g.drawImage(button, 200, 100, 400, 400, null);

   // Draw the arm image at its current horizontal position and fixed vertical position
   g.drawImage(arm, armX, 230, 150, 400, null);

   // Draw instructional text below the button
   g.setColor(Color.BLACK); // Set text color
   g.setFont(new Font("Arial", Font.BOLD, 18)); // Set text font and size
   g.drawString("Click the button with your mouse to move to the next scene quicker", 75, 530);
}


   /**
    * Main method creates a window and shows the Scene10T panel.
    * @param args Command line arguments (not used).
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene10T Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(new Scene10T()); // Add Scene10T panel to frame
      frame.setSize(800, 600);
      frame.setVisible(true);
   }

   /**
    * Starts the arm animation timer.
    */
   public void start(){
      timer.start();
   }

   /**
    * Stops the arm animation timer.
    */
   public void stop(){
      timer.stop();
   }
}
