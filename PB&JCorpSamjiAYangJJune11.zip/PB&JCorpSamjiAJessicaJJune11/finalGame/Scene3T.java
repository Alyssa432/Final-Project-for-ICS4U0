/*Glitchbreak: scene3 testing game
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene3T displays a character walking upward toward a satchel
 * with a background and simple frame-switching animation.
 */
public class Scene3T extends JPanel {
   private BufferedImage background, ch2, ch1, ch3, satchel; // Images for scene elements
   private int y, imgState; // y controls vertical movement; imgState switches animation frames
   private Timer walkTimer; // Timer for walking animation

   /**
    * Constructor sets panel size, background color, loads images, and configures animation timer.
    */
   public Scene3T() {
      setSize(800, 600);
      setBackground(new Color(176, 231, 255)); // Light blue sky
      y = 0;

      try {
         background = ImageIO.read(new File("background2.png")); // Background image
         ch2 = ImageIO.read(new File("standBack.png"));          // Standing frame
         ch1 = ImageIO.read(new File("walkBackLeft.png"));       // Walking frame 1
         ch3 = ImageIO.read(new File("walkBackRight.png"));      // Walking frame 2
         satchel = ImageIO.read(new File("satchel.png"));        // Satchel image
      } catch (IOException e) {
         e.printStackTrace();
      }

      // Timer controls vertical movement and character animation frame
      walkTimer = new Timer(85,
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               if (y < 200) {        // Only move while y is less than 200
                  y += 3;            // Move character upward
                  imgState++;        // Cycle through animation states
                  if (imgState > 2) imgState = 0;
                  repaint();         // Repaint panel with updated position/frame
               }
            }
         });
   }

   /**
    * paintComponent handles drawing all scene elements with current animation state.
    */
   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
      g.drawImage(background, 0, 0, 800, 600, null);                 // Draw background
      g.drawImage(satchel, 300, 548 - y, 160, 200, null);            // Draw satchel above character

      BufferedImage currentImg;
      if (imgState == 1)
         currentImg = ch1;                                           // Walk frame 1
      else if (imgState == 2)
         currentImg = ch3;                                           // Walk frame 2
      else
         currentImg = ch2;                                           // Standing

      g.drawImage(currentImg, 330, 400 - y, 158, 300, null);         // Draw character
   }

   /**
    * Starts the walk animation by starting the timer.
    */
   public void start() {
      walkTimer.start();
   }

   /**
    * Stops the walk animation by stopping the timer.
    */
   public void stop() {
      walkTimer.stop();
   }
}

