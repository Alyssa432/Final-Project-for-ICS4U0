/*Glitchbreak: scene4 testing game
Jessica Yang and Alyssa Samji final ISP project
Ms. Krasteva
Jun 11, 2025

The following code was written by Jessica Yang
*/

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

/**
 * Scene4T presents a fence obstacle and gives the user two choices:
 * "Jump" or "Change Ways." These are handled through on-screen buttons.
 */
public class Scene4T extends JPanel {
   private BufferedImage background, ch1, fence, satchel; // Scene images
   private boolean jumpChosen = false;         // Flag for "Jump" choice
   private boolean changeWaysChosen = false;   // Flag for "Change Ways" choice
   private boolean showDialogue;               // Controls whether dialogue box appears
   private JButton jumpButton, changeWaysButton; // Buttons for user choices
   private Timer dialogTimer;                  // Timer to delay showing dialogue/buttons

   /**
    * Constructor initializes scene graphics, buttons, and timer logic.
    */
   public Scene4T() {
      setBackground(new Color(176, 231, 255)); // Light blue background
      setLayout(null);                         // Absolute layout for button placement
      showDialogue = false;

      try {
         background = ImageIO.read(new File("background2.png")); // Background image
         ch1 = ImageIO.read(new File("standBack.png"));          // Character image
         fence = ImageIO.read(new File("fence.png"));            // Fence image
         satchel = ImageIO.read(new File("satchel.png"));        // Satchel image
      } catch (IOException e) {
         e.printStackTrace();
      }

      // Initialize buttons
      jumpButton = new JButton("Jump");
      changeWaysButton = new JButton("Change Ways");

      // Position buttons on screen
      jumpButton.setBounds(200, 350, 100, 30);
      changeWaysButton.setBounds(500, 350, 140, 30);

      jumpButton.setVisible(false);
      changeWaysButton.setVisible(false);

      add(jumpButton);
      add(changeWaysButton);

      // Handle jump button click using mouse
      jumpButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               jumpChosen = true;
            }
         });

      // Handle change ways button click using mouse
      changeWaysButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               changeWaysChosen = true;
            }
         });

      // Timer delays the appearance of the dialogue box and buttons
      dialogTimer = new Timer(1000,
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               showDialogue = true;
               jumpButton.setVisible(true);
               changeWaysButton.setVisible(true);
               repaint(); // Refresh screen to show dialogue and buttons
            }
         });

      dialogTimer.setRepeats(false); // Only fire once
   }

   /**
    * Starts the scene by starting the timer.
    */
   public void start() {
      dialogTimer.start();
   }

   /**
    * Stops the timer in case it's still running.
    */
   public void stop() {
      dialogTimer.stop();
   }

   /**
    * Draws the full scene, including background, character, and any dialogue.
    */
   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);

      g.drawImage(fence, 0, 0, 800, 600, null);                    // Draw fence first
      g.drawImage(background, 0, 0, 800, 600, null);               // Draw background
      g.drawImage(satchel, 300, 348, 160, 200, null);              // Draw satchel
      g.drawImage(ch1, 330, 200, 158, 300, null);                  // Draw character

      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);               // Black dialogue box
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 16));     
         g.drawString("A fence appears in your path. Will you jump the fence or", 70, 475);
         g.drawString("change ways? As you think, you hear a robotic whirr", 70, 500);
         g.drawString("getting closer...something is chasing you!", 70, 525);
      }
   }

   /**
    * Returns whether the "Jump" option was selected.
    */
   public boolean isJumped() {
      return jumpChosen;
   }

   /**
    * Returns whether the "Change Ways" option was selected.
    */
   public boolean changedWays() {
      return changeWaysChosen;
   }

   /**
    * Main method to test Scene4T independently.
    */
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene4T Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Scene4T scene = new Scene4T();
      frame.add(scene);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // Start the dialogue delay timer
   }
}
