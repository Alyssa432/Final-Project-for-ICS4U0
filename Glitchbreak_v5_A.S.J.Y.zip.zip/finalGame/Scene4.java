// Alyssa Samji and Jessica Yang
// Scene 4 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene4 extends JPanel {
    private int x = 0;
    private int imageState = 1; 
    private Timer timer;
    private BufferedImage walkRFoot, standLeft, walkLFoot, friendStandLeft, friendWalkRFoot, friendWalkLFoot, thinking;

public Scene4(JFrame frame) {
    try {
        walkRFoot = ImageIO.read(new File("walkRFoot.png"));
        standLeft = ImageIO.read(new File("standLeft.png"));
        walkLFoot = ImageIO.read(new File("walkLFoot.png"));
        friendStandLeft = ImageIO.read(new File("friendStandLeft.png"));
        friendWalkRFoot = ImageIO.read(new File("friendWalkRFoot.png"));
        friendWalkLFoot = ImageIO.read(new File("friendWalkLFoot.png"));
        thinking = ImageIO.read(new File("thinking.png"));
    } catch (IOException e) {
        e.printStackTrace();
    }
    timer = new Timer(150, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            x += 20;
            imageState++;
            if (imageState > 3) imageState = 1;
            repaint();
        }
    });
}

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Color sky = new Color(206, 237, 250);

        g.setColor(sky);
        g.fillRect(0, 0, getWidth(), 400);

        BufferedImage currentImage, currentImage2;

        if (imageState == 1) {
            currentImage = walkLFoot;
            currentImage2 = friendStandLeft;
        } else if (imageState == 2) {
            currentImage = standLeft;
            currentImage2 = friendWalkRFoot;
        } else {
            currentImage = walkRFoot;
            currentImage2 = friendWalkLFoot;
        }

        g.drawImage(currentImage2, 920 - x, 200, 150, 240, null);
        g.drawImage(currentImage, 845 - x, 200, 150, 240, null);

        Font serifFont = new Font("Serif", Font.BOLD, 15);
        g.setFont(serifFont);
        g.setColor(Color.BLACK);

        if (x > 200) {
            g.drawImage(thinking, 645 - x, 150, 200, 100, null);
            g.drawString("Did they not", 700 - x, 180);
            g.drawString("see the brick wall?", 685 - x, 200);
        }
}
   public void start() {
      timer.start();
   }

}