//no animation

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene6C1 extends JPanel {
   private BufferedImage button, wall;
   public Scene6C1 () {
      setBackground(new Color(200, 200, 200));
      try {
         button = ImageIO.read(new File("buttonOfDoom.png"));
         wall = ImageIO.read (new File ("wearAndTearLol.png"));
      }catch (IOException e) {}
   
   }
   
   @Override
   public void paintComponent (Graphics g) {
      super.paintComponent(g);
      
      g.drawImage(wall, 0, 0, 1000, 800, null);
      
      g.drawImage(button, 200, 100, 400, 400, null);
   }
   
   public static void main (String[] args) {
      JFrame frame = new JFrame("Scene6 choice 1 Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(new Scene6C1());
      frame.setSize(800, 600);
      frame.setVisible(true);
   }
}