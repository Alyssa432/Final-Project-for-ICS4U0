import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene7C1 extends JPanel {
   private BufferedImage ch1, ch2, robot, robotTextBox, wall;
   private Timer robotTimer, dialogueTimer;
   private boolean showRobot, showDialogue;

   public Scene7C1() {
      setBackground(new Color(200, 200, 200));
   
      try {
         ch1 = ImageIO.read(new File("scene7C1Focused.png"));
         ch2 = ImageIO.read(new File("scene7C1Scared.png"));
         robotTextBox = ImageIO.read(new File("spiky.png"));
         wall = ImageIO.read(new File("wearAndTearLol.png"));
         robot = ImageIO.read(new File("robot.png"));
      } catch (IOException e) {
         System.err.println("Error loading images: " + e.getMessage());
         e.printStackTrace();
      }
   
      // Dialogue timer
      dialogueTimer = new Timer(1000, 
         e -> {
            showDialogue = true;
            repaint();
         });
      dialogueTimer.setRepeats(false);
   
      // Robot timer
      robotTimer = new Timer(2500, 
         e -> {
            showRobot = true;
            repaint();
         });
      robotTimer.setRepeats(false);
   }

   public void start() {
      dialogueTimer.start();
      robotTimer.start();
   }
   
   public void stop() {
      robotTimer.stop();
      dialogueTimer.stop();
   }


   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
   
      // Background wall
      if (wall != null) {
         g.drawImage(wall, 0, 0, 800, 600, null);
      }
   
      // Ground
      g.setColor(new Color(100, 100, 100));
      g.fillRect(0, 450, getWidth(), 150);
   
      // Character before robot shows up
      g.drawImage(ch1, 330, 280, 250, 300, null);
   
      if (showRobot) {
         // Robot appears
         g.setColor(Color.WHITE);
         g.fillRect(80, 200, 150, 250); // Robot "door" border
         
         if (robot != null) {
            g.drawImage(robot, 120, 180, 200, 300, null);
         } else {
            g.setColor(Color.RED);
            g.fillRect(120, 180, 200, 300);
         }
      
         g.drawImage(ch2, 330, 280, 250, 300, null);
      
         if (robotTextBox != null) {
            g.drawImage(robotTextBox, 120, 260, 200, 200, null);
         }
      
         g.setColor(Color.RED);
         g.setFont(new Font("Courier New", Font.BOLD, 30));
         g.drawString("Halt!", 182, 378);
      }
   
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 500, 700, 80, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 14));
         g.drawString("Right when you think you're safe to leave, an AI robot appears,", 70, 535);
         g.drawString("catching you in the act!", 70, 550);
      
         // Red square indicator (dramatic?)
         g.setColor(Color.RED);
         g.fillRect(350, 490, 20, 10);
      }
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene7C1 Test");
      Scene7C1 scene = new Scene7C1();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(scene);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // Start the timers
   }
}
