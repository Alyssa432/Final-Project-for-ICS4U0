import javax.swing.*;
import java.awt.event.*;

public class Level2Runner {
   private static int x = 0; // Counter for timing transitions
   private static Timer timer;
   private static boolean reachedEnding2 = false;

   public static void startGame(JFrame frame) {
      frame.getContentPane().removeAll();
      frame.revalidate();
      frame.repaint();
   
      // Instantiate all scenes
      Scene1T scene1 = new Scene1T();
      Scene2T scene2 = new Scene2T();
      Scene3T scene3 = new Scene3T();
      Scene4T scene4 = new Scene4T();
      Scene5C1 scene5C1 = new Scene5C1();
      Scene5C2 scene5C2 = new Scene5C2();
      Scene6C1 scene6C1 = new Scene6C1();
      Scene6C2 scene6C2 = new Scene6C2();
      Scene7C1 scene7C1 = new Scene7C1(); 
      Scene7C2 scene7C2 = new Scene7C2();
   
      // Start first scene
      frame.getContentPane().add(scene1);
      frame.revalidate();
      frame.repaint();
      scene1.start();
   
      timer = new Timer(150, 
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               x++;
            
               if (x == 34) {
                  scene1.stop();
                  frame.remove(scene1);
                  frame.add(scene2);
                  frame.revalidate();
                  frame.repaint();
                  scene2.start(); 
               } else if (x == 101) {
                  if (scene2.wasPassed()) {
                     scene2.stop();
                     frame.remove(scene2);
                     frame.add(scene3);
                     frame.revalidate();
                     frame.repaint();
                     scene3.start(); 
                  } else {
                     x = 34; // Restart at Scene1
                     startGame(frame);
                     timer.stop();
                  }
               } else if (x == 230) {
                  scene3.stop();
                  frame.remove(scene3);
                  frame.add(scene4);
                  frame.revalidate();
                  frame.repaint();
                  scene4.start();
               }
               
               // Scene 5 branching logic
               else if (scene4.isJumped()) {
                  scene4.stop();
                  frame.remove(scene4);
                  frame.add(scene5C1);
                  frame.revalidate();
                  frame.repaint();
                  scene5C1.start();
               } else if (scene4.changedWays()) {
                  scene4.stop();
                  frame.remove(scene4);
                  frame.add(scene5C2);
                  frame.revalidate();
                  frame.repaint();
                  scene5C2.start();
               }
               
               // Scene 6 logic
               else if (x == 250) {
                  scene5C1.stop();
                  frame.remove(scene5C1);
                  frame.add(scene6C1);
                  frame.revalidate();
                  frame.repaint();
               } else if (x == 300) {
                  scene5C2.stop();
                  frame.remove(scene5C2);
                  frame.add(scene6C2);
                  frame.revalidate();
                  frame.repaint();
                  scene6C2.start();
               }
               
               // Scene 7 branching logic
               else if (x == 350) {
                  if (true) { // Replace with actual condition
                     frame.remove(scene6C1);
                     frame.add(scene7C1);
                     reachedEnding2 = false;
                     frame.revalidate();
                     frame.repaint();
                     scene7C1.start();
                  } else {
                     scene6C2.stop();
                     frame.remove(scene6C2);
                     frame.add(scene7C2);
                     reachedEnding2 = true;
                     frame.revalidate();
                     frame.repaint();
                     scene7C2.start();
                  }
               }
               
               // Loop or end game if Ending 2 was reached
               else if ((x == 430) && (reachedEnding2)) {
                  scene7C2.stop();
                  frame.remove(scene7C2);
                  x = 0;
                  timer.stop();
                  startGame(frame);
               }
            }
         });
   
      timer.start();
   }
}
