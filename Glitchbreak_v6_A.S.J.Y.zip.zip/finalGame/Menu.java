/* Jessica Yang and Alyssa Samji
Game Menu -- Jessica Yang
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import java.io.File;

public class Menu {
   private JPanel menuPanel;

   public Menu(JFrame frame) {
      menuPanel = new JPanel(new GridBagLayout());
      menuPanel.setBackground(new Color(242, 218, 241));
     
      PlayerManager.promptForName(frame);
   
      ImageIcon backgroundImg = new ImageIcon("glitchBreak.png");
      Image temp = backgroundImg.getImage();
      Image tempScaled = temp.getScaledInstance(800, 580, Image.SCALE_SMOOTH);
      backgroundImg = new ImageIcon(tempScaled);
      JLabel backgroundLabel = new JLabel(backgroundImg);
      backgroundLabel.setLayout(new GridBagLayout());
   
      JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 0, 10));
      buttonPanel.setOpaque(false);
      JButton instructionsButton = new JButton("Level 2");
      JButton playButton = new JButton("Level 1");
      JButton exitButton = new JButton("Exit");
      JButton leaderboard = new JButton("Leaderboard");
      buttonPanel.add(instructionsButton);
      buttonPanel.add(playButton);
      buttonPanel.add(leaderboard);
      buttonPanel.add(exitButton);
   
      backgroundLabel.add(buttonPanel);
      menuPanel.add(backgroundLabel);
   
      frame.getContentPane().add(menuPanel);
      frame.revalidate();
      frame.repaint();
   
      instructionsButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               Level2Runner.startGame(frame);
            }
         });
   
      playButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               Level1Runner.starts(frame);
            }
         });
         
      leaderboard.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               Leaderboard.starts(frame);
            }
         });
   
      exitButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               System.exit(0);
            }
         });
   }
}

// Resource: https://docs.oracle.com/javase/tutorial/uiswing/components/panel.html
//           https://stackoverflow.com/questions/1097366/java-swing-revalidate-vs-repaint