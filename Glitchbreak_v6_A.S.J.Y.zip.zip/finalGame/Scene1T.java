import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene1T extends JPanel { 
   private BufferedImage backgroundImg, ch1, thought, knock;
   private boolean showKnock;
   private Timer timer;

   public Scene1T() {
      setSize(800, 600);
      setBackground(Color.WHITE);
      showKnock = false;

      try {
         knock = ImageIO.read(new File("knock.png"));
         backgroundImg = ImageIO.read(new File("background.png"));
         ch1 = ImageIO.read(new File("char1.png"));
         thought = ImageIO.read(new File("thought.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }

      timer = new Timer(2000, new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            showKnock = true;
            repaint();
         }
      });
      timer.setRepeats(false);
   }

   public void start() {
      timer.start();
   }

   public void stop() {
      timer.stop();
   }

   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);

      Font serifFont = new Font("Serif", Font.BOLD, 20);
      g.setFont(serifFont);
      g.setColor(Color.BLACK);

      g.drawImage(backgroundImg, 0, 0, 800, 600, null);
      g.drawImage(ch1, -133, 280, 600, 400, null);
      g.drawImage(thought, 150, 60, 600, 400, null);
      g.drawString("I need to escap—I mean, go on vacation!", 280, 150);

      if (showKnock) {
         g.drawImage(knock, 400, 150, 400, 400, null);
      }
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene1T Test");
      Scene1T scene = new Scene1T();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(scene);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // Start the knock timer
   }
}
