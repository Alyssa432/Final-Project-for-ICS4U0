import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene10T extends JPanel {
   private BufferedImage button, wall, arm;
   private Timer timer;
   private int armX = -300;
   private JButton bigButton;

   public Scene10T() {
   setLayout(null);
      setBackground(new Color(200, 200, 200));

      try {
         button = ImageIO.read(new File("buttonOfDoom.png"));
         wall = ImageIO.read(new File("wearAndTearLol.png"));
         arm = ImageIO.read(new File("arm.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
      bigButton = new JButton("");
      bigButton.setFont(new Font("SansSerif", Font.BOLD, 24));
      bigButton.setBounds(338, 229, 102, 102);
      bigButton.setOpaque(false);
      bigButton.setContentAreaFilled(false);
      bigButton.setBorderPainted(false);
     
      bigButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
         timer.start();
         }
      });

      add(bigButton);

      timer = new Timer(60, new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            armX += 20;
            if (armX >= 300) {
               timer.stop();
            }
            repaint();
         }
      });
   }

   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      g.drawImage(wall, 0, 0, 1000, 800, null);
      g.drawImage(button, 200, 100, 400, 400, null);
      g.drawImage(arm, armX, 230, 150, 400, null);
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene10T Test");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(new Scene10T());
      frame.setSize(800, 600);
      frame.setVisible(true);
   }
}
