import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene2T extends JPanel {
   private BufferedImage ch2, mom1, mom2, backgroundImg, speech;
   private boolean showMom, showDialogue, showSpeech, showFailScreen, pass;
   private int imgState = 0, x = 0;

   private Timer momTimer, dialogTimer, moveMomTimer;

   public Scene2T() {
      setSize(800, 600);
      showMom = false;
      showDialogue = false;
      showFailScreen = false;
      pass = false;
      setDoubleBuffered(true);

      try {
         speech = ImageIO.read(new File("speechBubble.png"));
         backgroundImg = ImageIO.read(new File("background.png"));
         ch2 = ImageIO.read(new File("sideWalking2Flipped.png"));
         mom1 = ImageIO.read(new File("mom1.png"));
         mom2 = ImageIO.read(new File("mom2.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }

      moveMomTimer = new Timer(30, new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            if (x <= 600) {
               x += 5;
               imgState++;
               if (imgState > 2) {
                  imgState = 0;
               }
               repaint();
            } else {
               moveMomTimer.stop();
               dialogTimer.start();
            }
         }
      });

      momTimer = new Timer(500, new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            showMom = true;
            moveMomTimer.start();
         }
      });
      momTimer.setRepeats(false);

      dialogTimer = new Timer(500, new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            showDialogue = true;
            repaint();
         }
      });
      dialogTimer.setRepeats(false);

      addMouseListener(new MouseAdapter() {
         public void mouseClicked(MouseEvent e) {
            if (showDialogue) {
               showDialogue = false;
               showSpeech = true;
               repaint();

               String input = JOptionPane.showInputDialog("Tell mom something...");

               if (input != null) {
                  input = input.toLowerCase();
                  if (input.contains("escape") || input.contains("leave")) {
                     showFailScreen = true;
                     repaint();
                  } else {
                     pass = true;
                  }
               }
            }
         }
      });
   }

   public boolean wasPassed() {
      return pass;
   }

   public void start() {
      momTimer.start();
   }

   public void stop() {
      momTimer.stop();
      moveMomTimer.stop();
      dialogTimer.stop();
   }

   @Override
   public void paint(Graphics g) {
      super.paint(g);

      g.drawImage(backgroundImg, 0, 0, 800, 600, null);
      g.drawImage(ch2, 70, 250, 170, 400, null);

      if (showMom) {
         BufferedImage currentImg = mom1;
         if (imgState == 1) {
            currentImg = mom1;
         }
         if (imgState == 2) {
            currentImg = mom2;
         }
         g.drawImage(currentImg, 200, 800 - x, 900, 600, null);
      }

      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 16));
         g.drawString("Try to tell mom you're leaving without", 70, 490);
         g.drawString("triggering AI's auto-correct!", 70, 515);
         g.setFont(new Font("Courier New", Font.PLAIN, 11));
         g.drawString("click anywhere to continue!", 200, 540);
      }

      g.setFont(new Font("Courier New", Font.PLAIN, 16));

      if (showSpeech) {
         g.drawImage(speech, 200, 220, 300, 300, null);
         g.drawString("Hey, mom. Actually...", 280, 320);
      }

      if (showFailScreen) {
         g.setColor(Color.BLACK);
         g.fillRect(0, 0, getWidth(), getHeight());

         g.setColor(Color.RED);
         g.setFont(new Font("Courier New", Font.BOLD, 36));
         g.drawString("The AI caught you! Fail!", 120, 300);
      }
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene2T Test");
      Scene2T scene = new Scene2T();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(scene);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start();
   }
}