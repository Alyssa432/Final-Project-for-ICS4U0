import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Scene11T extends JPanel {
   private BufferedImage pod, faceForwardSassy;

   public Scene11T() {
      setBackground(Color.GRAY);
      try {
         pod = ImageIO.read(new File("pod.png"));
         faceForwardSassy = ImageIO.read(new File("faceForwardSassy.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   protected void paintComponent(Graphics g) {
      super.paintComponent(g);

      g.drawImage(faceForwardSassy, 300, 200, 200, 400, null);
      g.drawImage(pod, 50, 20, 700, 800, null);
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene11T");
      frame.setSize(800, 600);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setContentPane(new Scene11T());
      frame.setVisible(true);
   }
}