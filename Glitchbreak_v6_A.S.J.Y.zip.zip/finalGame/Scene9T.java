import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene9T extends JPanel{
   private BufferedImage sadRobot, pourWater, robotText, wall;
   private boolean showDialogue;
   private Timer dialogTimer;
   
   public Scene9T() {
      showDialogue = false;
      setBackground(new Color(200, 200, 200));
   
      try {
         pourWater = ImageIO.read(new File("pourWater.png"));
         wall = ImageIO.read(new File("wearAndTearLol.png"));
         sadRobot = ImageIO.read(new File("robotSad.png"));
         robotText = ImageIO.read(new File("spiky.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   
      dialogTimer = new Timer(1000, 
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               showDialogue = true;
               repaint();
            }
         });
      dialogTimer.setRepeats(false);
   }

   public void start() {
      dialogTimer.start();
   }
   
   public void stop() {
      dialogTimer.stop();
   }

   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
   
      g.drawImage(wall, 0, 0, 800, 600, null);
   
      g.setColor(new Color(100, 100, 100));
      g.fillRect(0, 450, getWidth(), 150);
   
      
      g.drawImage(sadRobot, 50, 300, 130, 200, null);
      g.drawImage(pourWater, 100, 200, 240, 300, null);
   
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 500, 700, 80, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 16));
         g.drawString("When you reach the robot, you grab the", 70, 520);
         g.drawString("water out of a satchel and dump it on him. ", 70, 560);
      }
   }
   
   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene9T");
      frame.setSize(800, 600);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setContentPane(new Scene9T());
      frame.setVisible(true);
   }

}