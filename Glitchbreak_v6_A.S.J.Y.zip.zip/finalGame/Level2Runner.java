import javax.swing.*;
import java.awt.event.*;

public class Level2Runner {
   private static int x = 0;
   private static Timer timer;
   private static boolean reachedEnding2 = false;
   private static boolean choice1Chosen = false;

   private static Scene1T scene1;
   private static Scene2T scene2;
   private static Scene3T scene3;
   private static Scene4T scene4;
   private static Scene5C1 scene5C1;
   private static Scene5C2 scene5C2;
   private static Scene6C1 scene6C1;
   private static Scene6C2 scene6C2;
   private static Scene7C1 scene7C1;
   private static Scene7C2 scene7C2;
   private static Scene8 scene8;
   private static Scene9 scene9;
   private static Scene10 scene10;
   private static Scene11 scene11;


   private static boolean scene5Started = false;
   private static boolean scene6Started = false;
   private static boolean scene7Started = false;

   public static void startGame(JFrame frame) {
      x = 0;
      scene5Started = false;
      scene6Started = false;
      scene7Started = false;
      reachedEnding2 = false;
   
      scene1 = new Scene1T();
      scene2 = new Scene2T();
      scene3 = new Scene3T();
      scene4 = new Scene4T();
      scene5C1 = new Scene5C1();
      scene5C2 = new Scene5C2();
      scene6C1 = new Scene6C1();
      scene6C2 = new Scene6C2();
      scene7C1 = new Scene7C1();
      scene7C2 = new Scene7C2();
      scene8 = new Scene8();
      scene9 = new Scene9();
      scene10 = new Scene10();
      scene11 = new Scene11();
   
   
      frame.getContentPane().removeAll();
      frame.revalidate();
      frame.repaint();
   
      frame.add(scene1);
      frame.revalidate();
      frame.repaint();
   
      scene1.start();
   
      timer = new Timer(100, 
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               x++;
            
               if (x == 34) {
                  scene1.stop();
                  frame.remove(scene1);
                  frame.add(scene2);
                  frame.revalidate();
                  frame.repaint();
                  scene2.start();
               } 
               
               else if (x == 110) {
                  if (scene2.wasPassed()) {
                     scene2.stop();
                     frame.remove(scene2);
                     frame.add(scene3);
                     frame.revalidate();
                     frame.repaint();
                     scene3.start();
                  } else {
                     timer.stop();
                     startGame(frame);
                  }
               }
               
               else if (x == 168) {
                  scene3.stop();
                  frame.remove(scene3);
                  frame.add(scene4);
                  frame.revalidate();
                  frame.repaint();
                  scene4.start();
               }
               
               else if (!scene5Started && x >= 235 && x <= 240) {
                  scene5Started = true;
               
                  scene4.stop();
                  frame.remove(scene4);
               
                  if (scene4.isJumped()) {
                     System.out.println("Jump detected - loading Scene5C1");
                     frame.add(scene5C1);
                     choice1Chosen = true;
                     scene5C1.start();
                  } else if (scene4.changedWays()) {
                     System.out.println("Changed ways detected - loading Scene5C2");
                     frame.add(scene5C2);
                     choice1Chosen = false;
                     scene5C2.start();
                  } else {
                     System.out.println("No choice made yet.");
                  // Optional: fallback or loop until user makes a choice
                  }
               
                  frame.revalidate();
                  frame.repaint();
               }
               
               else if (!scene6Started && x == 300) {
                  scene6Started = true;
                  if (choice1Chosen) {
                     scene5C1.stop();
                     frame.remove(scene5C1);
                     frame.add(scene6C1);
                     frame.revalidate();
                     frame.repaint();
                  } else {
                     scene5C2.stop();
                     frame.remove(scene5C2);
                     frame.add(scene6C2);
                     scene6C2.start();
                     frame.revalidate();
                     frame.repaint();
                  }
               }
               
               else if (!scene7Started && x == 367) {
                  scene7Started = true;
               
                  if (choice1Chosen) {
                     frame.remove(scene6C1);
                     frame.add(scene7C1);
                     reachedEnding2 = false;
                     frame.revalidate();
                     frame.repaint();
                     scene7C1.start();
                  } else {
                     scene6C2.stop();
                     frame.remove(scene6C2);
                     frame.add(scene7C2);
                     reachedEnding2 = true;
                     frame.revalidate();
                     frame.repaint();
                     scene7C2.start();
                  }
               } 
               else if (x == 410) {
                  if (reachedEnding2) {
                     scene7C2.stop();
                     frame.remove(scene7C2);
                     timer.stop();
                     startGame(frame);
                  } else {
                     scene7C1.stop();
                     frame.remove(scene7C1);
                     frame.add(scene8);
                     scene8.start();
                     frame.revalidate();
                     frame.repaint();
                  }
               }                
               else if (x == 478 && !reachedEnding2) {
                  scene8.stop();
                  frame.remove(scene8);
                  frame.add(scene9);
                  scene9.start();
                  frame.revalidate();
                  frame.repaint();
               }
               
               else if (x == 535 && !reachedEnding2) {
                  scene9.stop();
                  frame.remove(scene9);
                  frame.add(scene10);
                  scene10.start();
                  frame.revalidate();
                  frame.repaint();
               }
               
               else if (x == 602 && !reachedEnding2) {
                  scene10.stop();
                  frame.remove(scene10);
                  frame.add(scene11);
                  scene11.start();
                  frame.revalidate();
                  frame.repaint();
               }
               
               else if (x == 669 && !reachedEnding2) {
                  
                  scene11.stop();
                  frame.remove(scene11);
                  frame.revalidate();
                  frame.repaint();
                  timer.stop();
                  //frame.dispose(); // close the window
                  //System.exit(0);  // terminate the program
               
               }
            
            }
         });
   
      timer.start();
   }
}  
