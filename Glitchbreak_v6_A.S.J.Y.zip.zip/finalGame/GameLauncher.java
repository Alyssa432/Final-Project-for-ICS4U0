import javax.swing.JFrame;

public class GameLauncher {
   public static void main(String[] args) {
      JFrame frame = new JFrame("GlitchBreak");
      frame.setSize(800, 600);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);

      new Menu(frame);
   }
}

//ONNLY LEARNING GAME WORKS!! IF U WANT TO TRY LEVEL 2, GO TO LEVEL 2RUNNER AND RUN FROM THERE!