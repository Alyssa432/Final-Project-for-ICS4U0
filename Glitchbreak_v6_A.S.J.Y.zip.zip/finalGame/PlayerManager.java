import javax.swing.*;
import java.io.*;
import java.util.*;

public class PlayerManager {
    private static String playerName = null;
    private static final ArrayList<String> letters = new ArrayList<>(Arrays.asList(
        "A","B","C","D","E","F","G","H","I","J","K","L","M","N",
        "O","P","Q","R","S","T","U","V","W","X","Y","Z"));

    public static void promptForName(JFrame frame) {
        if (playerName != null) return;

        while (true) {
            String input = JOptionPane.showInputDialog(frame, "Enter your name:");
            if (input == null || input.trim().equals("")) continue;

            input = input.trim();
            if (isDuplicate(input)) {
                JOptionPane.showMessageDialog(frame, "That name is taken. Try another.");
            } else {
                playerName = input;
                saveName(input);
                break;
            }
        }
    }

    private static boolean isDuplicate(String name) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("players"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equalsIgnoreCase(name)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException e) {
        }
        return false;
    }

    private static void saveName(String name) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter("players", true));
            writer.println(name);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getPlayerName() {
        return playerName;
    }
    public static ArrayList<String> getLetters() {
    return letters;
}

}

// To learn ArrayAsList: https://www.geeksforgeeks.org/array-to-arraylist-conversion-in-java/