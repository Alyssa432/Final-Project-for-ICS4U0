// Alyssa Samji and Jessica Yang
// Scen6 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene6 extends JPanel {
   private int x = 0;
   private BufferedImage friendStandBack, standBack, textBox, spa;
   private Timer timer;

   public Scene6(JFrame frame) {
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);
   
      returnButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               timer.stop();
               new Menu(frame);
            }
         });
           
      try {
         friendStandBack = ImageIO.read(new File("friendStandBack.png"));
         standBack = ImageIO.read(new File("standBack.png"));
         textBox = ImageIO.read(new File("TextBoxReverse.png"));
         spa = ImageIO.read(new File("spa.png"));
      } catch (IOException e) {
      }
      timer = new Timer(150,
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               x += 1;
               repaint();
            }
         });
   }

   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      g.setFont(serifFont);
     
      Color sky = new Color(206, 237, 250);
      Color grass = new Color(170, 239, 80);
   
      g.setColor(sky);
      g.fillRect(0, 0, 800, 600);
     
      g.setColor(grass);
      g.fillRect(0, 300, 800, 300);
           
      g.setColor(Color.GRAY);
      int[] yPoints = {300, 300, 600, 600};
      int[] xPoints = {300, 500, 800, 0};
      g.fillPolygon(xPoints, yPoints, 4);
            g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);
   
      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);
   
      g.setColor(Color.BLACK);
      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);


      g.drawImage(spa, 200, 50, 400, 300, null);
     
      g.setColor(Color.RED);
      g.setFont(new Font("Serif", Font.BOLD, 50));
      g.drawString("POP!", 650, 300);

      g.drawImage(standBack, 505, 245, 200, 400, null);
      g.drawImage(friendStandBack, 100, 260, 200, 400, null);  
     
      g.drawImage(textBox, 710, 150, 160, 150, null);

          g.setFont(serifFont);
          g.setColor(Color.BLACK);
          g.drawString("What the", 745, 210);
          g.drawString("heck?!", 755, 230);
      }
   public void start() {
      timer.start();
   }
   public void stop(){
   timer.stop();
   }

}