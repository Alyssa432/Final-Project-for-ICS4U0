import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene7C2 extends JPanel {
   private int transparency;
   private BufferedImage standLeft, background, robot;
   private Timer dialogTimer, rainTimer, failTimer;
   private boolean showDialogue, showFailScreen;
   private int[] rainX, rainY, rainSpeed;

   public Scene7C2() {
      setBackground(new Color(176, 231, 255));
      showDialogue = false;
      showFailScreen = false;
   
      try {
         background = ImageIO.read(new File("background3.png"));
         standLeft = ImageIO.read(new File("standLeft.png"));
         robot = ImageIO.read(new File("robot.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   
      // Initialize rain drop arrays
      int numDrops = 100;
      rainX = new int[numDrops];
      rainY = new int[numDrops];
      rainSpeed = new int[numDrops];
   
      for (int i = 0; i < numDrops; i++) {
         rainX[i] = (int)(Math.random() * 800);
         rainY[i] = (int)(Math.random() * 600);
         rainSpeed[i] = 2 + (int)(Math.random() * 4);
         
         dialogTimer = new Timer(800, 
            new ActionListener() {
               public void actionPerformed(ActionEvent e) {
                  showDialogue = true;
                  repaint();
               }
            });
         dialogTimer.setRepeats(false);
      
         rainTimer = new Timer(20, 
            new ActionListener() {
               public void actionPerformed(ActionEvent e) {
                  for (int i = 0; i < rainY.length; i++) {
                     rainY[i] += rainSpeed[i];
                     if (rainY[i] > 600) {
                        rainY[i] = 0;
                        rainX[i] = (int)(Math.random() * 800);
                     }
                  }
                  repaint();
               }
            });
      
         failTimer = new Timer(3500, 
            new ActionListener() {
               public void actionPerformed(ActionEvent e) {
                  showFailScreen = true;
                  repaint();
               }
            });
         failTimer.setRepeats(false);
      
      }
   }
   
   public void start() {
      dialogTimer.start();
      rainTimer.start();
      failTimer.start();
   }
   
   public void stop() {
      dialogTimer.stop();
      rainTimer.stop();
      failTimer.stop();
   }

   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
   
      // Grey overlay for dramatic sky
      g.setColor(new Color(128, 128, 128, 160));
      g.fillRect(0, 0, getWidth(), getHeight());
   
      // Background and characters
      g.drawImage(background, 0, 0, 800, 600, null);
      g.drawImage(standLeft, 600, 200, 130, 210, null);
      g.drawImage(robot, 100, 200, 180, 210, null);
   
      // Rain drops
      g.setColor(new Color(255, 255, 255, 150));
      for (int i = 0; i < rainX.length; i++) {
         g.drawLine(rainX[i], rainY[i], rainX[i], rainY[i] + 10);
      }
   
      // Dialogue
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 14));      
         g.drawString("Suddenly, you're stopped by a robotic whir. 'You shall not pass, human!'", 70, 470);
         g.drawString("They've caught onto you! Before you can even think about it, there's a flash,", 70, 495);
         g.drawString("and you are sent back home.", 70, 520);
      }
   
      // Fail screen
      if (showFailScreen) {
         g.setColor(Color.BLACK);
         g.fillRect(0, 0, getWidth(), getHeight());
         g.setColor(Color.RED);
         g.setFont(new Font("Courier New", Font.BOLD, 36));
         g.drawString("The AI caught you! Fail!", 120, 300);
      }
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene7C2 Test");
      Scene7C2 scene = new Scene7C2();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(scene);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // Start animation after frame is visible
   }
}
