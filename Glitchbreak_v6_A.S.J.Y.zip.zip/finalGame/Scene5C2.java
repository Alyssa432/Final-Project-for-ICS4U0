import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene5C2 extends JPanel {

   private int x = 0;
   private int imageState = 1; 
   private BufferedImage walkRFoot, standLeft, walkLFoot, fence, background;
   private Timer walkTimer, dialogTimer;
   private boolean showDialogue;
   
   public Scene5C2() {
      setBackground(new Color(176, 231, 255));
      showDialogue = false;
      
      try {
         background = ImageIO.read(new File("background2.png"));
         fence = ImageIO.read(new File("fence.png"));
         walkRFoot = ImageIO.read(new File("walkRFoot.png"));
         standLeft = ImageIO.read(new File("standLeft.png"));
         walkLFoot = ImageIO.read(new File("walkLFoot.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }

      walkTimer = new Timer(200, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            x += 20;
            imageState++;
            if (imageState > 3) imageState = 1;
            repaint();
         }
      });

      dialogTimer = new Timer(800, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            showDialogue = true;
            repaint();
         }
      });
      dialogTimer.setRepeats(false);
   }

   public void start() {
      walkTimer.start();
      dialogTimer.start();
   }
   
   public void stop() {
    walkTimer.stop();
    dialogTimer.stop();
}


   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
     
      g.drawImage(fence, 0, 0, 800, 600, null); 
      g.drawImage(background, 0, 0, 800, 600, null);
   
      BufferedImage currentImage;
      if (imageState == 1) {
         currentImage = walkLFoot;
      } else if (imageState == 2) {
         currentImage = standLeft;
      } else {
         currentImage = walkRFoot;
      }
      g.drawImage(currentImage, 200 - x, 200, 120, 200, null);
      
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 14));      
         g.drawString("You decide to walk on the grass, along the fence. No", 70, 470);
         g.drawString("one has ever walked on the grass before. It is pristine", 70, 495);
         g.drawString("and perfect and...", 70, 515);
         g.setColor(Color.RED);
         g.drawString("fake.", 250, 515);
         g.setColor(Color.WHITE);
         g.drawString("But you keep going.", 300, 515);
         g.drawString("The fence must end somewhere, right?", 70, 535); 
      }
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene5C2 Test");
      Scene5C2 scene = new Scene5C2();
      frame.add(scene);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // trigger animation and dialogue
   }
}
