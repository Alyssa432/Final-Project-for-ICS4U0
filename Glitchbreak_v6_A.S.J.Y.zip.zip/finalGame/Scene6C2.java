import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;

public class Scene6C2 extends JPanel {

   private int x, transparency;
   private int imageState = 1; 
   private BufferedImage walkRFoot, standLeft, walkLFoot, background;
   private Timer walkTimer, dialogTimer, rainTimer, greyFadeTimer;
   private boolean showDialogue;
   private int[] rainX, rainY, rainSpeed;

   public Scene6C2() {
      setBackground(new Color(176, 231, 255));
      showDialogue = false;
      transparency = 0;
   
      try {
         background = ImageIO.read(new File("background3.png"));
         walkRFoot = ImageIO.read(new File("walkRFoot.png"));
         standLeft = ImageIO.read(new File("standLeft.png"));
         walkLFoot = ImageIO.read(new File("walkLFoot.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
   
      // Rain arrays setup
      int numDrops = 100;
      rainX = new int[numDrops];
      rainY = new int[numDrops];
      rainSpeed = new int[numDrops];
   
      for (int i = 0; i < numDrops; i++) {
         rainX[i] = (int)(Math.random() * 800);
         rainY[i] = (int)(Math.random() * 600);
         rainSpeed[i] = 2 + (int)(Math.random() * 4);
      }
   
      // WALK TIMER
      walkTimer = new Timer(200, 
         e -> {
            x += 20;
            imageState = (imageState % 3) + 1;
            repaint();
         });
   
      // DIALOGUE TIMER
      dialogTimer = new Timer(800, 
         e -> {
            showDialogue = true;
            repaint();
         });
      dialogTimer.setRepeats(false);
   
      // RAIN TIMER
      rainTimer = new Timer(30, 
         e -> {
            for (int i = 0; i < rainY.length; i++) {
               rainY[i] += rainSpeed[i];
               if (rainY[i] > 600) {
                  rainY[i] = 0;
                  rainX[i] = (int)(Math.random() * 800);
               }
            }
            repaint();
         });
   
      // GREY FADE TIMER
      greyFadeTimer = new Timer(100, 
         e -> {
            if (transparency < 160) {
               transparency += 3;
               repaint();
            } else {
               greyFadeTimer.stop();
            }
         });
   }

   public void start() {
      walkTimer.start();
      dialogTimer.start();
      rainTimer.start();
      greyFadeTimer.start();
   }
   
   public void stop() {
      walkTimer.stop();
      dialogTimer.stop();
      rainTimer.stop();
      greyFadeTimer.stop();
   }


   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
   
      // Greying skies
      g.setColor(new Color(128, 128, 128, transparency));
      g.fillRect(0, 0, getWidth(), getHeight());
   
      g.drawImage(background, 0, 0, 800, 600, null);
   
      // Walk animation
      BufferedImage currentImage = 
         switch (imageState) {
            case 1 -> walkLFoot;
            case 2 -> standLeft;
            case 3 -> walkRFoot;
            default -> standLeft;
         };
      g.drawImage(currentImage, 845 - x, 200, 120, 200, null);
   
      // Rain
      g.setColor(new Color(255, 255, 255, 150));
      for (int i = 0; i < rainX.length; i++) {
         g.drawLine(rainX[i], rainY[i], rainX[i], rainY[i] + 10);
      }
   
      // Dialogue
      if (showDialogue) {
         g.setColor(Color.BLACK);
         g.fillRoundRect(50, 450, 700, 100, 20, 20);
         g.setColor(Color.WHITE);
         g.setFont(new Font("Courier New", Font.PLAIN, 14));
         g.drawString("As you continue walking, it starts to...well. You think it's rain,", 70, 470);
         g.drawString("but you're not sure, because it has never rained before. The weather has", 70, 495);
         g.drawString("always been sunny and perfect. Everything is too robotic, too...unreal.", 70, 515);
         g.drawString("Something is trying to stop you. But it only motivates you to keep going.", 70, 535);
      }
   }

   public static void main(String[] args) {
      JFrame frame = new JFrame("Scene6C2 Test");
      Scene6C2 scene = new Scene6C2();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(scene);
      frame.setSize(800, 600);
      frame.setVisible(true);
      scene.start(); // Start timers
   }
}
