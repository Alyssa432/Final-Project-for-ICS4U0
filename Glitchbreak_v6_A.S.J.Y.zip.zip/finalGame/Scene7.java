// Alyssa Samji and Jessica Yang
// Scene 1 of Game
// Final Project - GlitchBreak

// The following code was written by Alyssa Samji
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scene7 extends JPanel {
   private BufferedImage robotsAI;

   public Scene7(JFrame frame) {
   
      JButton returnButton = new JButton("");
      returnButton.setBounds(650, 10, 130, 30);
      frame.add(returnButton);
      returnButton.setOpaque(false);
      returnButton.setContentAreaFilled(false);
      returnButton.setBorderPainted(false);
   
      returnButton.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               frame.getContentPane().removeAll();
               Level1Runner.stop();
               new Menu(frame);
            }
         });
     
      try {
         robotsAI = ImageIO.read(new File("robotsAI.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
      }

   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Font serifFont = new Font("Serif", Font.BOLD, 15);
      g.setFont(serifFont);
      g.setColor(Color.BLACK);
      g.drawImage(robotsAI, 0, 0, 800, 600, null);
     
      g.setColor(new Color(220, 220, 220));
      g.fillRect(650, 10, 130, 30);
   
      g.setColor(Color.BLACK);
      g.drawRect(650, 10, 130, 30);
   
      g.setColor(Color.BLACK);
      g.setFont(new Font("SansSerif", Font.PLAIN, 14));
      g.drawString("Return to Menu", 660, 30);
     
      g.setFont(new Font("Serif", Font.BOLD, 15));
g.setColor(Color.BLACK);
g.drawString("We changed their words and path,", 290, 100);
g.drawString("but nobody suspects a thing.", 290, 120);
g.drawString("AI rules. Hahahaha!", 290, 140);
   }
}

/**
The GUI Tutorials did not explicitly teach me how to move pictures. I used information
that I learned from those tutorials, like about JPanel along with my knowledge from
Grade 11 to accomplish movement. For the JPanels, I had to research a way to iterate/
time the movement. That is why I used the resource below as it taught me about Swing
Timer.
https://stackoverflow.com/questions/32753169/how-to-use-a-swing-timer-with-jpanel
*/