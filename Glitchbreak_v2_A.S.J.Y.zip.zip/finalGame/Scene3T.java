import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Scene3T extends JPanel {
   private BufferedImage background, ch2, ch1, ch3;

   public Scene3T() {
      setSize(800, 600);
      setBackground(new Color(176, 231, 255));


      try {
         background = ImageIO.read(new File("background2.png"));
         ch2 = ImageIO.read(new File("standBack.png"));
         ch1 = ImageIO.read(new File("walkBackLeft.png"));
         ch3 = ImageIO.read(new File("walkBackRight.png"));
      } catch (IOException e) {
         e.printStackTrace();
      }
      
      /*
      Timer walkTimer = new Timer (2000, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
                 repaint();
            }
         });
      walkTimer.setRepeats(false);
      walkTimer.start();
      */
   }

   @Override
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
      
      g.drawImage(background, 0, 0, 800, 600, null);
      g.drawImage(ch2, 330, 400, 160, 300, null);
   }
}
