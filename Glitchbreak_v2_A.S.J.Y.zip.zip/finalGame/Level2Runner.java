import javax.swing.*;

public class Level2Runner {
   public static void startGame(JFrame frame) {
      frame.getContentPane().removeAll(); 
      frame.revalidate();
      frame.repaint();
   
      Scene1T scene1 = new Scene1T();
      Scene2T scene2 = new Scene2T();
      Scene3T scene3 = new Scene3T();
   
      frame.add(scene1);
      frame.setVisible(true);
   
      try {
         Thread.sleep(5000);
      } catch (Exception e) {}
   
      frame.remove(scene1);
      frame.add(scene2);
      frame.setVisible(true);
   
      try {
         Thread.sleep(10000);
      } catch (Exception e) {}
   
      // Check if scene2 was passed (AI didn't catch)
      if (scene2.wasPassed()) {
         frame.remove(scene2);
         frame.add(scene3);
         frame.setVisible(true);
      
         try {
            Thread.sleep(10000);
         } catch (Exception e) {}
      }
      
      // Close frame after scene3 or if failed in scene2
      frame.dispose();
   }
}
